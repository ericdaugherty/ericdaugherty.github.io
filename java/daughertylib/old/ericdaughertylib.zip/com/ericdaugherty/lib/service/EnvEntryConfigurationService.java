/*
 * $Archive: /ericdaughertylib/src/com/ericdaugherty/lib/service/EnvEntryConfigurationService.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 10/09/01 10:55a $
 *
 * (c) 2000 Eric Daugherty
 */

package com.ericdaugherty.lib.service;

//java imports
import javax.naming.*;
import java.util.Hashtable;
import java.util.Properties;

//Log4j imports
import org.apache.log4j.Category;

//local imports
import com.ericdaugherty.lib.error.SystemException;

/**
 * This class provides access to all configuration information
 * available to this application.
 */
public class EnvEntryConfigurationService extends ConfigurationService {
    
    //***************************************************************
    // Constructor
    //***************************************************************

    /**
     * Creates a new instance and calls the initialize method.
     */
    private EnvEntryConfigurationService() throws SystemException {
        initialize( ENV_CONTEXT_NAME );
    }

    //***************************************************************
    // Public Interface
    //***************************************************************
    
    /**
     * Returns the singleton instance of this class.  If the instance
     * has not yet been created, a new instance is created and returned.
     * 
     * @return the EnvEntryConfigurationService singleton instance
     */
    public static EnvEntryConfigurationService getInstance() throws SystemException {
        if( _envEntryConfigurationService == null ) {
            synchronized( EnvEntryConfigurationService.class ) {
                if( _envEntryConfigurationService == null ) {
                    _envEntryConfigurationService = new EnvEntryConfigurationService();
                }
            }
        }
        return _envEntryConfigurationService;
    }
    
    //***************************************************************
    // Private Interface
    //***************************************************************
    
    //***************************************************************
    // Variables

    /** Singleton Instance */
    private static EnvEntryConfigurationService _envEntryConfigurationService = null;
    
    /** Logger Category for this class.  */
    private static Category _log = Category.getInstance( EnvEntryConfigurationService.class.getName() );

    //***************************************************************
    // Constants
    
    private static final String ENV_CONTEXT_NAME = "java:comp/env";
   
 }
//EOF