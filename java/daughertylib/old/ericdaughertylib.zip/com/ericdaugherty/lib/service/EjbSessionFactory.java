/*
 * $Archive: /ericdaughertylib/src/com/ericdaugherty/lib/service/EjbHomeFactory.java $
 * $Revision: 2 $
 * $Author: Edaugherty $
 * $Date: 10/09/01 2:20p $
 *
 * (c) 2000 Eric Daugherty
 */

package com.ericdaugherty.lib.service;

//java imports
import javax.ejb.*;
import java.lang.reflect.*;
import java.rmi.*;
import java.util.*;
import javax.naming.*;

//Log4j imports
import org.apache.log4j.Category;

//local imports
import com.ericdaugherty.lib.error.SystemException;

/**
 * Provides a mechanism to cache and lookup EJB Stateless SessionBeans 
 * Local and Remote interfaces.
 */
public class EjbSessionFactory {
    
    //***************************************************************
    // Constructor
    //***************************************************************

    /**
     * Creates a new instance and calls the initialize method.
     */
    private EjbSessionFactory() throws SystemException {

		_ejbInterfaces = Collections.synchronizedMap( new HashMap() );
    }

    //***************************************************************
    // Public Interface
    //***************************************************************
    
	/**
	 * Retrieves the specified EJB Local/Remote interface.
	 * 
	 * @param jndiName the name to use to lookup this object in the JNDI Tree.
	 * @param Local/Remote class used in the PortableRemoteObject.narror call after the lookup.
	 * @return Local/Remote interface.
	 */
	public static Object lookupInterface( String homeJndiName, Class homeClass ) throws SystemException
	{
		EjbSessionFactory instance = EjbSessionFactory.getInstance();
		
		Object ejbInterface = instance._ejbInterfaces.get( homeJndiName );
			
		if( ejbInterface == null ) {
			
			Object ejbHome = EjbHomeFactory.lookupHome( homeJndiName, homeClass );
			
			ejbInterface = createRemote( ejbHome );
			
			instance._ejbInterfaces.put( homeJndiName, ejbInterface );
		}
		
		return ejbInterface;
    }

	//***************************************************************
    // Private Interface
    //***************************************************************
    
	/**
     * Returns the singleton instance of this class.  If the instance
     * has not yet been created, a new instance is created and returned.
     * 
     * @return the EjbHomeFactory singleton instance
     */
    private static EjbSessionFactory getInstance() throws SystemException {
        if( _ejbSessionFactory == null ) {
            synchronized( EjbSessionFactory.class ) {
                if( _ejbSessionFactory == null ) {
                    _ejbSessionFactory = new EjbSessionFactory();
                }
            }
        }
        return _ejbSessionFactory;
    }
	
	/**
	 * Creates a new Remote interface from the Home Interface passed
	 * to this method using reflection.  This method assumes a
	 * create method with no parameters exists on the Home Interface.
	 *
	 * @param home the EJBHome(or EjbLocalHome) interface to use to create the Remote Interface.
	 *
	 * @return the Remote Interface
	 *
	 * @exception SystemException thrown when an error occurs performing the
	 * call to the create() method on the Home Interface.
	 */
    private static final Object createRemote(Object home)
    	throws SystemException {

		Method method = null;

		//Create a Method instance for the ejbHome create() method.
		try{
			method = home.getClass().getMethod( CREATE_METHOD_NAME, null );
		}
		catch( NoSuchMethodException nsme ) {
			throw new SystemException( "The specified remote interface does not have a \"" + CREATE_METHOD_NAME + "\" method", nsme );
		}

		//Method takes no parameters, so create an emtpy object array.
		Object[] parameters = new Object[0];

		//Invoke and return the create method.
		try {
			return  method.invoke( home, parameters );
		}
		catch( IllegalAccessException iae ) {
			throw new SystemException( "IllegalAccessException occured while invoking create method", iae );
		}
		catch( InvocationTargetException ite ) {
			throw new SystemException( "InvocationTargetException occured while invoking create method", ite );
		}
	}
	
    //***************************************************************
    // Variables

    /** Singleton Instance */
    private static EjbSessionFactory _ejbSessionFactory = null;
	
	/** Cache of previously retrieved Ejb Home Interfaces */
	private Map _ejbInterfaces;
  
    /** Logger Category for this class.  */
    private static Category _log = Category.getInstance( EjbSessionFactory.class.getName() ); 
	
	//***************************************************************
    // Constants
	
	private static final String CREATE_METHOD_NAME = "create";
 }
//EOF