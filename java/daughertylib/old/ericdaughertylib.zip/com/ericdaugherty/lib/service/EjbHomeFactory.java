/*
 * $Archive: /ericdaughertylib/src/com/ericdaugherty/lib/service/EjbHomeFactory.java $
 * $Revision: 2 $
 * $Author: Edaugherty $
 * $Date: 10/09/01 2:20p $
 *
 * (c) 2000 Eric Daugherty
 */

package com.ericdaugherty.lib.service;

//java imports
import javax.ejb.*;
import java.rmi.*;
import java.util.*;
import javax.naming.*;

//Log4j imports
import org.apache.log4j.Category;

//local imports
import com.ericdaugherty.lib.error.SystemException;

/**
 * Provides a mechanism to cache and lookup EJBHome objects.
 */
public class EjbHomeFactory {
    
    //***************************************************************
    // Constructor
    //***************************************************************

    /**
     * Creates a new instance and calls the initialize method.
     */
    private EjbHomeFactory() throws SystemException {

		_ejbHomes = Collections.synchronizedMap( new HashMap() );
    }

    //***************************************************************
    // Public Interface
    //***************************************************************
    
	/**
	 * Retrieves the specified EJBHome object.
	 * 
	 * @param jndiName the name to use to lookup this object in the JNDI Tree.
	 * @param homeClass used in the PortableRemoteObject.narror call after the lookup.
	 * @return Home instance.
	 */
	public static Object lookupHome( String jndiName, Class homeClass ) throws SystemException
	{
		EjbHomeFactory instance = getInstance();
		
		Object ejbHome = instance._ejbHomes.get( jndiName );
		
		if( ejbHome == null ) {
			try {
				ejbHome = javax.rmi.PortableRemoteObject.narrow (
						  JndiService.getInstance().lookup( jndiName ), homeClass );
				instance._ejbHomes.put( jndiName, ejbHome );
			}
			catch( NamingException ne ) {
				throw new SystemException( "Error Looking up EJBHome: " + jndiName, ne );
			}
		}
		
		return ejbHome;
    }

	//***************************************************************
    // Private Interface
    //***************************************************************
    
	/**
     * Returns the singleton instance of this class.  If the instance
     * has not yet been created, a new instance is created and returned.
     * 
     * @return the EjbHomeFactory singleton instance
     */
    private static EjbHomeFactory getInstance() throws SystemException {
        if( _ejbHomeFactory == null ) {
            synchronized( ConfigurationService.class ) {
                if( _ejbHomeFactory == null ) {
                    _ejbHomeFactory = new EjbHomeFactory();
                }
            }
        }
        return _ejbHomeFactory;
    }
	
    //***************************************************************
    // Variables

    /** Singleton Instance */
    private static EjbHomeFactory _ejbHomeFactory = null;
	
	/** Cache of previously retrieved Ejb Home Interfaces */
	private Map _ejbHomes;
  
    /** Logger Category for this class.  */
    private static Category _log = Category.getInstance( EjbHomeFactory.class.getName() ); 
 }
//EOF