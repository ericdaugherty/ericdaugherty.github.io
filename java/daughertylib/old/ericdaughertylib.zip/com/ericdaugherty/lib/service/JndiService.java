/*
 * $Archive: /ericdaughertylib/src/com/ericdaugherty/lib/service/JndiService.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 10/09/01 10:55a $
 *
 * (c) 2000 Eric Daugherty
 */

package com.ericdaugherty.lib.service;

//java imports
import javax.naming.*;

//Log4j imports
import org.apache.log4j.Category;

//local imports
import com.ericdaugherty.lib.error.SystemException;

/**
 * Provides simplified access to the JNDI tree.  This class caches an
 * InitialContext object and performs all lookups on the cached
 * context.
 */
public class JndiService {
    
    //***************************************************************
    // Constructor
    //***************************************************************

    /**
     * Creates a new instance and calls the initialize method.
     */
    private JndiService() throws SystemException, NamingException {
		//TODO: Replace this with configurable InitialContext
		_context = new InitialContext();
    }

    //***************************************************************
    // Public Interface
    //***************************************************************
    
    /**
     * Returns the singleton instance of this class.  If the instance
     * has not yet been created, a new instance is created and returned.
     * 
     * @return the JndiService singleton instance
     */
    public static JndiService getInstance() throws SystemException, NamingException {
        if( _jndiService == null ) {
            synchronized( JndiService.class ) {
                if( _jndiService == null ) {
                    _jndiService = new JndiService();
                }
            }
        }
        return _jndiService;
    }
	
	/**
	 * Performs a JNDI Lookup on the cached Context.
	 * 
	 * @param the JNDI name to use to query the context.
	 * @return the result of the JNDI Lookup.
	 */
	public Object lookup( String jndiName ) throws NamingException {
		
		return _context.lookup( jndiName );
	}
	    
    //***************************************************************
    // Private Interface
    //***************************************************************
    
    //***************************************************************
    // Variables

    /** Singleton Instance */
    private static JndiService _jndiService = null;
	
	/** The JNDI Context to use */
	private Context _context;
  	
    /** Logger Category for this class.  */
    private static Category _log = Category.getInstance( JndiService.class.getName() );

    //***************************************************************
    // Constants
   
 }
//EOF