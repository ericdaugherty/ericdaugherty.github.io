/******************************************************************************
 * $Workfile: ConfigurationService.java $
 * $Revision: 2 $
 * $Author: Edaugherty $
 * $Date: 6/26/01 1:40p $
 *
 ******************************************************************************
 * Copyright (c) 2001, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are permitted provided 
 * that the following conditions are met:
 * 
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the 
 *   following disclaimer. 
 * 
 *   Redistributions in binary form must reproduce the 
 *   above copyright notice, this list of conditions and 
 *   the following disclaimer in the documentation and/or 
 *   other materials provided with the distribution. 
 * 
 *   Neither the name of Eric Daugherty nor the names of its 
 *   contributors may be used to endorse or promote products 
 *   derived from this software without specific prior written 
 *   permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.service;

//java imports
import javax.naming.*;
import java.util.Hashtable;
import java.util.Properties;

//Log4j imports
import org.apache.log4j.Category;

//local imports
import com.ericdaugherty.lib.error.SystemException;

/**
 * This class provides access to all configuration information
 * available to this application.
 * <p>
 * This class provides a nice front end to the code to query configuration
 * parameters from a JNDI server.  
 * 
 * @author Eric Daugherty
 */
public abstract class ConfigurationService {
    
    //***************************************************************
    // Public Interface
    //***************************************************************
    
    /**
     * Retrieve the appropritate context to use to look up all environment
     * variables.
     * 
     * @param baseContext the context to use as the base for all lookups
     * 
     * @exception SystemException thrown when there is a NamingException
     *            thrown when trying to lookup the appropriate context.
     */
    public void initialize( String baseContext ) throws SystemException {
        
        try {
            InitialContext initialContext = new InitialContext();
            _envContext = (Context) initialContext.lookup( baseContext );   
        }
        catch( NamingException ne ) {
            _log.error( INITIAL_NAMING_ERROR + baseContext, ne );
            throw new SystemException( INITIAL_NAMING_ERROR + baseContext, ne );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Object.
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Object value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    public Object getObject( String entryName ) throws SystemException {
       
        return getProperty( entryName );
    }
    
    /**
     * Looks up the entryName parameter and returns it as a String.
     * 
     * Example:
     * <env-entry>
     *     <description>Your Property Description</description>
     *     <env-entry-name>myString</env-entry-name>
     *     <env-entry-type>java.lang.String</env-entry-type>
     *     <env-entry-value>Hello World<env-entry-value>
     * </env-entry>
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return String value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    public String getString( String entryName ) throws SystemException {
        
        try {
            return (String) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            _log.error( CLASS_CAST_ERROR + entryName, cce );
            throw new SystemException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Byte
     * 
     * Example:
     * <env-entry>
     *     <description>Your Property Description</description>
     *     <env-entry-name>myByte</env-entry-name>
     *     <env-entry-type>java.lang.Byte</env-entry-type>
     *     <env-entry-value>1<env-entry-value>
     * </env-entry>
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Byte value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    public Byte getByte( String entryName ) throws SystemException {
        
        try {
            return (Byte) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            _log.error( CLASS_CAST_ERROR + entryName, cce );
            throw new SystemException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Short
     * 
     * Example:
     * <env-entry>
     *     <description>Your Property Description</description>
     *     <env-entry-name>myShort</env-entry-name>
     *     <env-entry-type>java.lang.Short</env-entry-type>
     *     <env-entry-value>1<env-entry-value>
     * </env-entry>
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Short value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    public Short getShort( String entryName ) throws SystemException {
        
        try {
            return (Short) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            _log.error( CLASS_CAST_ERROR + entryName, cce );
            throw new SystemException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Integer
     * 
     * Example:
     * <env-entry>
     *     <description>Your Property Description</description>
     *     <env-entry-name>myInteger</env-entry-name>
     *     <env-entry-type>java.lang.Byte</env-entry-type>
     *     <env-entry-value>100<env-entry-value>
     * </env-entry>
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Integer value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    public Integer getInteger( String entryName ) throws SystemException {
        
        try {
            return (Integer) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            _log.error( CLASS_CAST_ERROR + entryName, cce );
            throw new SystemException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Long
     * 
     * Example:
     * <env-entry>
     *     <description>Your Property Description</description>
     *     <env-entry-name>myLong</env-entry-name>
     *     <env-entry-type>java.lang.Long</env-entry-type>
     *     <env-entry-value>1<env-entry-value>
     * </env-entry>
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Long value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    public Long getLong( String entryName ) throws SystemException {
        
        try {
            return (Long) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            _log.error( CLASS_CAST_ERROR + entryName, cce );
            throw new SystemException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Boolean.
     * 
     * Example:
     * <env-entry>
     *     <description>Your Property Description</description>
     *     <env-entry-name>myBoolean</env-entry-name>
     *     <env-entry-type>java.lang.Boolean</env-entry-type>
     *     <env-entry-value>true<env-entry-value>
     * </env-entry>
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Boolean value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    public Boolean getBoolean( String entryName ) throws SystemException {
        
        try {
            return (Boolean) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            _log.error( CLASS_CAST_ERROR + entryName, cce );
            throw new SystemException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Double
     * 
     * Example:
     * <env-entry>
     *     <description>Your Property Description</description>
     *     <env-entry-name>myDouble</env-entry-name>
     *     <env-entry-type>java.lang.Double</env-entry-type>
     *     <env-entry-value>1.0<env-entry-value>
     * </env-entry>
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Double value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    public Double getDouble( String entryName ) throws SystemException {
        
        try {
            return (Double) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            _log.error( CLASS_CAST_ERROR + entryName, cce );
            throw new SystemException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Float
     * 
     * Example:
     * <env-entry>
     *     <description>Your Property Description</description>
     *     <env-entry-name>myFloat</env-entry-name>
     *     <env-entry-type>java.lang.Float</env-entry-type>
     *     <env-entry-value>1.0<env-entry-value>
     * </env-entry>
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Float value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    public Float getFloat( String entryName ) throws SystemException {
        
        try {
            return (Float) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            _log.error( CLASS_CAST_ERROR + entryName, cce );
            throw new SystemException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * This method takes a context name, and returns all the Entry Names/Values
     * in a properties object.
     * 
     * @param context the initial context to load the properties from.  This method
     *                prepends the default context to this parameter, so the context
     *                parameter should start with the the portion after the default.
     * 
     * @return a Properties object with all the environment entries for the specified
     *         context.
     * 
     * @exception SystemException occurs if there are any NamingExceptions thrown during
     *            the execution of this method.
     */
    public Properties buildContextProperties( String context ) throws SystemException {
        try {
            
            //Retrieve a list of all entry names
            NamingEnumeration namingEnum = _envContext.list( context );
            
            NameClassPair nameClassPair;
            String entryName;
            Properties properties = new Properties();
            
            //Build properties object.
            while( namingEnum.hasMore() ) {
                
                nameClassPair = (NameClassPair) namingEnum.next();
                entryName = nameClassPair.getName();
                properties.put( entryName, String.valueOf( _envContext.lookup( context + "/" + entryName ) ) );
            }
            return properties;
        }
        catch( NamingException ne ) {
            _log.debug( PROPERTIES_NAMING_ERROR + context, ne );  
            throw new SystemException( PROPERTIES_NAMING_ERROR + context, ne );
        }
    }
    
    //***************************************************************
    // Private Interface
    //***************************************************************

    /**
     * Looks up the property and returns it as an Object.  If any exceptions
     * are throw, they are caught, logged (as .debug() ), and a new 
     * SystemException is thrown.
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Object value of the configuration entry.
     * 
     * @exception SystemException thrown if any errors occur performing this lookup.
     */
    private Object getProperty( String entryName ) throws SystemException {       
        
        if( _envContext == null ) {
            throw new SystemException( "The Configuration Service has not been initialized.  Please call initialize( String baseContext)" );
        }
        
        try {
            return _envContext.lookup( entryName );
        }
        catch( NamingException ne ) {
            _log.error( NAMING_ERROR + entryName, ne );
            throw new SystemException( NAMING_ERROR + entryName, ne );
        }
    }
    
    //***************************************************************
    // Variables

    /** Logger Category for this class.  */
    private static Category _log = Category.getInstance( ConfigurationService.class.getName() );
    
    private Context _envContext;

    //***************************************************************
    // Constants
    
    private static final String INITIAL_NAMING_ERROR = "Error retriving context: ";
    private static final String NAMING_ERROR = "Error retrieving configuration value for entry name: ";
    private static final String CLASS_CAST_ERROR = "Error casting value for entry name: ";
    private static final String PROPERTIES_NAMING_ERROR = "Naming error occured while building properties file for context: ";
}
//EOF