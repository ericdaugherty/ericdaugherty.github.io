/******************************************************************************
 * $Workfile: CascadingException.java $
 * $Revision: 2 $
 * $Author: Edaugherty $
 * $Date: 6/26/01 1:40p $
 *
 ******************************************************************************
 * Copyright (c) 2001, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are permitted provided 
 * that the following conditions are met:
 * 
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the 
 *   following disclaimer. 
 * 
 *   Redistributions in binary form must reproduce the 
 *   above copyright notice, this list of conditions and 
 *   the following disclaimer in the documentation and/or 
 *   other materials provided with the distribution. 
 * 
 *   Neither the name of Eric Daugherty nor the names of its 
 *   contributors may be used to endorse or promote products 
 *   derived from this software without specific prior written 
 *   permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.error;

//java imports
import java.io.*;

/**
 * Provides the ability to 'cascade' exceptions.  This exception can be created 
 * and passes another exception.  When this exception is displayed, the information
 * from this exception is displayed, along with the info from the exception passed
 * to this class
 * 
 * @author Eric Daugherty
 */
public class CascadingException extends Exception implements Serializable { 
    
    public CascadingException() {
    }
    
    public CascadingException( Exception e ) {
        System.out.println( "In CascadingException( e ) : " + e.toString() );
        this.nestedException = e;
        stackTraceString = generateStackTraceString( e );
    }
    
    public CascadingException( String msg ) {
        super(msg);
    }
    
    public CascadingException( String msg, Exception e ) {
        this(msg);
        this.nestedException = e;
        stackTraceString = generateStackTraceString( e );
    }

    // convert a stack trace to a String so it can be serialized
    static public String generateStackTraceString(Throwable t) {
        StringWriter s = new StringWriter();
        t.printStackTrace(new PrintWriter(s));
        return s.toString();
    }

    // methods
    public Throwable getNestedException() {return nestedException;}

    // descend through linked-list of nesting exceptions, & output trace
    // note that this displays the 'deepest' trace first
    public String getStackTraceString() {
        // if there's no nested exception, there's no stackTrace
        if (nestedException == null)
            return getMessage();

        StringBuffer traceBuffer = new StringBuffer();

        if (nestedException instanceof CascadingException) {
            
            traceBuffer.append(((CascadingException)nestedException).getStackTraceString());
            traceBuffer.append("-------- nested by:\n");
        }

        traceBuffer.append(stackTraceString);
        return traceBuffer.toString();
    }

    // overrides Exception.getMessage()
    public String getMessage() {
        // superMsg will contain whatever String was passed into the
        // constructor, and null otherwise.
        String superMsg = super.getMessage();

        // if there's no nested exception, do like we would always do
        if (getNestedException() == null)
            return superMsg;

        StringBuffer theMsg = new StringBuffer();

        // get the nested exception's message
        String nestedMsg = getNestedException().getMessage();

        if (superMsg != null)
            theMsg.append(superMsg).append(": ").append(nestedMsg);
        else
            theMsg.append(nestedMsg);

        return theMsg.toString();
    }

    // overrides Exception.toString()
    public String toString() {
        StringBuffer theMsg = new StringBuffer(super.toString());

        if (getNestedException() != null)
            theMsg.append("; \n\t---> nested ").append(getNestedException());

        return theMsg.toString();
    }

    public void printStackTrace() {
        System.out.println( getStackTraceString() );    
    }
    
    public void printStackTrace(PrintWriter s) {
        s.print( getStackTraceString() );
    }
    
    public void printStackTrace(PrintStream s) {
        s.print( getStackTraceString() );
    }
    
    // the nested exception
    private Throwable nestedException;

    // String representation of stack trace - not transient!
    private String stackTraceString;
    
}
//EOF