/******************************************************************************
 * $Workfile: ValidationService.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 10/18/01 5:03p $
 *
 ******************************************************************************
 * Copyright (c) 2001, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are permitted provided 
 * that the following conditions are met:
 * 
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the 
 *   following disclaimer. 
 * 
 *   Redistributions in binary form must reproduce the 
 *   above copyright notice, this list of conditions and 
 *   the following disclaimer in the documentation and/or 
 *   other materials provided with the distribution. 
 * 
 *   Neither the name of Eric Daugherty nor the names of its 
 *   contributors may be used to endorse or promote products 
 *   derived from this software without specific prior written 
 *   permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.struts;

//Struts imports
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Provides the ability perform common input parameter validation compatible with
 * Apache Jakarta's Struts.  These methods perform validation on the parameters, 
 * and use add an ActionError if the fields are not valid.
 * <p>
 * The names of the ActionError string names are hard coded in this class.  Here
 * is a list of the strings used, along with an example.  Please create an entry for
 * each of these strings in your ApplicationResources.properties file.<br>
 * <name> - <example>
 * <ul>
 * <li>validation.no.value - Please enter a value for this field.</li>
 * <li>validation.too.long - Please enter a value that is no longer than {0} charecter(s).</li>
 * <li>validation.wrong.length - Please enter a value between {0} and {1} charecters long.</li>
 * <li>validation.password.no.match - The passwords entered did not match.</li>
 * <li>validation.email.wrong.format - Please enter a valid email address (x@y.z).</li>
 * </ul>
 */
public class ValidationService {
    
    /**
     * This method verifies that the value parameter has a value.
     * 
     * @param errors the ActionErrors instance to add new ActionError instances to.
     * @param name the name of the bean parameter.
     * @param value the value of the bean parameter.
     * 
     * @return true if the value parameter has a value, false if it is null or an empty string.
     */
    public static boolean validateField( ActionErrors errors, String name, String value ) {
     
        if( value == null || value.equals( "" ) ) {
            errors.add( name, new ActionError( VALIDATION_NO_VALUE ) );
            return false;
        }
        else {
            return true;
        }
    }
    
    /**
     * This method verifies that the value parameter is less than or equal to the max 
     * length.  This method also verifies that the value is not null.
     * 
     * @param errors the ActionErrors instance to add new ActionError instances to.
     * @param name the name of the bean parameter.
     * @param value the value of the bean parameter.
     * @param max the maxmim size this field can be.
     * 
     * @return true if the value parameter has a value, false if it is null or an empty string.
     */
    public static boolean validateField( ActionErrors errors, String name, String value, int max ) {
     
        boolean valid = true;
        
        if( validateField( errors, name, value ) &&
            !(value.length() <= max) ) {
            
            errors.add( name, new ActionError( VALIDATION_TOO_LONG, String.valueOf( max ) ) );
            valid = false;
        }  
        
        return valid;
    }
    
    /**
     * This method verifies that the value parameter is between the specified
     * min and max values.  This method also verifies that the value is not null.
     * 
     * @param errors the ActionErrors instance to add new ActionError instances to.
     * @param name the name of the bean parameter.
     * @param value the value of the bean parameter.
     * 
     * @return true if the value parameter has a value, false if it is null or an empty string.
     */
    public static boolean validateField( ActionErrors errors, String name, String value, int min, int max ) {
     
        boolean valid = true;
        
        if( validateField( errors, name, value ) &&
            !(value.length() >= min && value.length() <= max ) ) {
            errors.add( name, new ActionError( VALIDATION_WRONG_LENGTH, String.valueOf( min ), String.valueOf( max ) ) );
            valid = false;
        }  
        
        return valid;
    }
    
    /**
     * This method verifies that the password parameters have values, are between the 
     * minimum and maximum values, and are in the correct format (x@y.zz)
     * 
     * 
     */
    public static boolean validatePassword( ActionErrors errors, 
                                            String password, 
                                            String password2,
                                            int min,
                                            int max ) {
     
        boolean valid = false;
        
        if( validateField( errors, "password", password, min, max ) &
            validateField( errors, "password2", password2, min, max ) ) {
            
            if( password.equals( password2 ) ) {
                valid = true;
            }
            else {
                errors.add( "password", new ActionError( VALIDATION_PASSWORD_NO_MATCH ) );
            }
        }   
        return valid;
    }
    
    /**
     * This method verifies that the email address has a value and is in 
     * the correct format.
     * 
     * @param errors the ActionErrors instance to add new ActionError instances to.
     * @param value the value of the bean emailAddress.
     * @param max the maximum size allowable for the email address field.
     */
    public static boolean validateEmailAddress( ActionErrors errors,
                                                String emailAddress,
                                                int max ) {
        
        boolean valid = false;
        
        if( validateField( errors, "emailAddress", emailAddress, max ) ) {
            int atIndex = emailAddress.indexOf( "@" );
            int dotIndex = emailAddress.indexOf( ".", atIndex );
            
            if( atIndex < 1 || dotIndex < atIndex ) {
                errors.add( "emailAddress", new ActionError( VALIDATION_EMAIL_WRONG_FORMAT ) );
            }
            else {
                valid = true;
            }
        }
        
        return valid;
    }
    
    //***************************************************************
    // Variables

    /** Logger Category for this class.  */
    private static Log _log = LogFactory.getLog( ValidationService.class.getName() );

    //***************************************************************
    // Constants

	//Validation General Error Messages
    private static final String VALIDATION_NO_VALUE = "validation.no.value";
    private static final String VALIDATION_TOO_LONG = "validation.too.long";
    private static final String VALIDATION_WRONG_LENGTH = "validation.wrong.length";
    private static final String VALIDATION_PASSWORD_NO_MATCH = "validation.password.no.match";
    private static final String VALIDATION_EMAIL_WRONG_FORMAT = "validation.email.wrong.format";

}
//EOF