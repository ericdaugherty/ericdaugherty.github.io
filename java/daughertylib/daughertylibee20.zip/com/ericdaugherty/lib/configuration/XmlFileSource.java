/******************************************************************************
 * $Workfile: XmlFileSource.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 5/21/02 8:23p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration;

//Java imports
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;
import java.util.Iterator;
import javax.xml.parsers.*;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//SAX imports
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

//Local imports
import com.ericdaugherty.lib.error.ConfigurationException;

/**
 * Provides an implementation of the ConfigurationSource interface to
 * read configuration information from a standard Java .properties file.
 *
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class XmlFileSource extends FileSource {

    //***************************************************************
    // ConfigurationSource Implementation Methods
    //***************************************************************

    /**
     * Provides access to the parameters defined by the configuration
     * source implementation.
     * <p>
     * Configuration sources should (re)load configuration information when this method
     * is called.  This method will only be called when the ConfigurationService wants
     * new configuration information from a source.
     *
     * @exception ConfigurationException thrown if the source cannot return the requested configuration data.
     */
    public ConfigurationData getConfigurationData() throws ConfigurationException {

        if( _file == null ) {
            throw new ConfigurationException( "XmlFileSource must be initialized before calling getConfigurationData()" );
        }

        try {
            SAXParserFactory parserFactory = SAXParserFactory.newInstance();
            SAXParser parser = parserFactory.newSAXParser();

            XmlHandler handler = new XmlHandler();

            parser.parse( _file,  handler );

            return handler.getConfigurationData();
        }
        catch( IOException ioe ) {
            throw new ConfigurationException( "IOException while loading the file: " + _file.getAbsolutePath(), ioe );
        }
        catch( ParserConfigurationException pce ) {
            throw new ConfigurationException( "Error loading Xml Parser.", pce );
        }
        catch( SAXException se ) {
            throw new ConfigurationException( "Unable to parse the Xml File.", se );
        }
    }

    //***************************************************************
    // Variables
    //***************************************************************

    /** Logger instance */
	private static Log _log = LogFactory.getLog( PropertyFileSource.class );


    /**
     * Parses an XML file into ConfigurationData
     */
    public class XmlHandler extends DefaultHandler {

        /**
         * Receive notification of the start of an element.
         * <p>
         * For each new element, add the element's name to the
         * _currentKey list.
         */
        public void startElement( String uri, String localName, String qName, Attributes attributes )
                throws SAXException {

            if( documentStarted ) {
                _currentKey.add( qName );
            }
            else {
                if( qName.equalsIgnoreCase( "configuration" ) ) {
                    documentStarted = true;
                }
            }
        }

        /**
         * Receive notification of the end of an element.
         * <p>
         * Every time an element ends, trim off the last element
         * in the _currentKey list.
         */
        public void endElement(String s, String s1, String s2) throws SAXException {

            //Only remove elements if we have started adding them.
            if( documentStarted ) {

                int index = _currentKey.size();
                //The opening element is never added, so we need to make
                //sure we don't try to remove it.
                if( index > 0 ) {
                    _currentKey.remove( index - 1 );
                }
            }
        }

        /**
         * If the current element has a value, add it to the keys/values lists.
         */
        public void characters(char[] chars, int i, int i1) throws SAXException {

            StringBuffer keyBuffer;
            String key;
            Iterator nodeIterator;
            String value = String.valueOf( chars, i , i1 ).trim();

            //Check to see if it actually contains data.
            if( value.length() > 0 ) {

                keyBuffer = new StringBuffer();
                nodeIterator = _currentKey.iterator();

                //Conver the list of keys to a properly delimited key.
                while( nodeIterator.hasNext() ) {
                    keyBuffer.append( nodeIterator.next() );
                    if( nodeIterator.hasNext() ) {
                        keyBuffer.append( _delimiter );
                    }
                }

                key = keyBuffer.toString();

                //Log the new Key/Value
                if( _log.isTraceEnabled() ) {
                    _log.trace( "XMLFileSource parsing key/value: " + key.toString() + "/" + value );
                }

                //Add to new key/value pair.
                _keys.add( key.toString() );
                _values.add( value );
            }
        }

        /**
         * Returns the configuration data that was loaded from the xml parser.
         */
        public ConfigurationData getConfigurationData() {

            return new ConfigurationData( _keys, _values );
        }

        //***************************************************************
        // Variables
        //***************************************************************

        String _delimiter = ConfigurationService.getInstance().getDelimiter();

        Collection _keys = new ArrayList();
        Collection _values = new ArrayList();

        boolean documentStarted = false;

        ArrayList _currentKey = new ArrayList();
    }

}

//EOF
