/******************************************************************************
 * $Workfile: WebXmlSource.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 5/21/02 8:23p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration;

//Java imports
import java.util.Properties;
import java.util.Enumeration;
import java.util.Collection;
import java.util.ArrayList;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//Local imports
import com.ericdaugherty.lib.error.SystemException;
import com.ericdaugherty.lib.error.ConfigurationException;
import com.ericdaugherty.lib.service.JndiConfigurationService;

/**
 * Provides an implementation of the ConfigurationSource interface to read
 * configuration information from a web.xml file.  This configuration
 * source must be loaded from a Servlet.
 * <p>
 * This Source assumes that the delimiter used (if any) in
 * the source is identical to the getDelimiter() method
 * on the ConfigurationSource singleton.  If the delimiters are different,
 * it can be specified using the initialize method or the setDelimiter()
 * method.
 * <p>
 * Due to the useage of JndiConfigurationService, this source does not
 * guarentee the order of the keys.  Therefore, if a single key is defined
 * multiple itmes in the web.xml file, the behaviour is undefined.  However
 * the Environment keywords are still handled correctly.
 * <p>
 * Variables are set in web.xml file using the following format:
 * <br>
 * <env-entry>
 *     <env-entry-name>your.parameter.key</env-entry-name>
 *     <env-entry-type>java.lang.String</env-entry-type>
 *     <env-entry-value>Parameter value<env-entry-value>
 * </env-entry>
 *
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class WebXmlSource implements ConfigurationSource {

    //***************************************************************
    // ConfigurationSource Implementation Methods
    //***************************************************************

    /**
     * Allows the WebXmlSource to be passed parameters from an external class.
     * This allows WebXmlSource to be initialized from a configuration
     * source instead of programmatically.
     *
     * @exception ConfigurationException thrown if the source cannot successfully be initialized with
     * the provided parameters.
     */
    public void initialize( ConfigurationService service, Properties properties) throws ConfigurationException {

        _jndiService = new JndiConfigurationService( ENV_CONTEXT_NAME );

        String delimiter = properties.getProperty( DELIMITER );
        if( delimiter != null && !delimiter.trim().equals( "" ) ) {
            _delimiter = delimiter;
        }
    }

    /**
     * Provides access to the parameters defined by the configuration
     * source implementation.
     * <p>
     * Configuration sources should (re)load configuration information when this method
     * is called.  This method will only be called when the ConfigurationService wants
     * new configuration information from a source.
     *
     * @exception ConfigurationException thrown if the source cannot return the requested configuration data.
     */
    public ConfigurationData getConfigurationData() throws ConfigurationException {

        if( _jndiService == null ) {
            throw new ConfigurationException( "WebXmlSource must be initialized before calling getConfigurationData()" );
        }

        Properties properties = _jndiService.buildContextProperties( "" );

        Collection keyData = new ArrayList();
        Collection valueData = new ArrayList();
        boolean defaultDelimiter = _service.getDelimiter().equals( _delimiter );

        Enumeration keys = properties.keys();
        String key;
        String parsedKey;

        while( keys.hasMoreElements() ) {
            key = (String) keys.nextElement();

            //If the delimiter for this file is different than the ConfigurationService's
            //default delimiter, parse this key to the appropriate delmitier.
            if( !defaultDelimiter ) {
                parsedKey = _service.convertDelimiter( key, _delimiter );
            }
            else {
                parsedKey = key;
            }

            keyData.add( parsedKey );
            valueData.add( properties.getProperty( key ) );
        }

        ConfigurationData data = new ConfigurationData( keyData, valueData );

        return data;
    }


    /**
     * Sets the delimiter to use to parse the keys.
     * <p>
     * If this parameter is not specified, "." is used.
     *
     * @param delimiter to use to parse the file.
     */
    public void setDelimiter( String delimiter ) {
        _delimiter = delimiter;
    }

    //***************************************************************
    // Variables
    //***************************************************************

    /** JNDI Service reference */
    private JndiConfigurationService _jndiService;

    /** Delimiter to use to parse the keys. */
    private String _delimiter = ".";

    private ConfigurationService _service = null;

    /** Logger instance */
    private static Log _log = LogFactory.getLog( WebXmlSource.class );

    //***************************************************************
    // Constants
    //***************************************************************

    private static final String ENV_CONTEXT_NAME = "java:comp/env";

    private static final String DELIMITER = "delimiter";

}

//EOF
