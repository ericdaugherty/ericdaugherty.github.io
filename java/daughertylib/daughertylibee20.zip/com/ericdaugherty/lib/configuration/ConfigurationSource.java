/******************************************************************************
 * $Workfile: ConfigurationSource.java $
 * $Revision: 2 $
 * $Author: Edaugherty $
 * $Date: 5/21/02 8:23p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration;

//Java imports
import java.util.Properties;

//Local imports
import com.ericdaugherty.lib.error.ConfigurationException;

/**
 * Defines the interface between the ConfigurationService, and any 
 * implementations that wish to provide access to configuration information.
 *  
 * Please refer to the configuration package 
 * <a href="package-summary.html#configuration_sources">documentation</a> for complete
 * documentation and useage information.
 * 
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public interface ConfigurationSource {

    /**
     * Allows the ConfigurationSource implementation to be passed parameters from
     * an external class.  This allows ConfigurationSources to be initialized from
     * a configuration source instead of programmatically.
     * <p>
     * All ConfigurationSource implementations should have a default (no parameter) constructor.
     *
     * @param service reference to the default or named singleton instance of the ConfigurationService
     * @param properties instance containing any source specific configuration parameters.
     *
     * @exception ConfigurationException thrown if the source cannot successfully be initialized with
     * the provided parameters.
     */
    public void initialize( ConfigurationService service, Properties properties ) throws ConfigurationException;

	/**
	 * Provides access to the parameters defined by the configuration
	 * source implementation.
     * <p>
     * Configuration sources should (re)load configuration information when this method
     * is called.  This method will only be called when the ConfigurationService wants
     * new configuration information from a source.
     *
     * @exception ConfigurationException thrown if the source cannot return the requested configuration data.
	 */
	public ConfigurationData getConfigurationData() throws ConfigurationException;
	
}
//EOF