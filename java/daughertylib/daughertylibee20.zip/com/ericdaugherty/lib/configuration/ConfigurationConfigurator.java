/******************************************************************************
 * $Workfile: ConfigurationConfigurator.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 5/21/02 8:23p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration;

//Java imports
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import java.util.ArrayList;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//Local imports
import com.ericdaugherty.lib.error.ConfigurationException;
import com.ericdaugherty.lib.error.NotFoundException;

/**
 * Provides a mechanism to configure a set of <code>ConfigurationSource</code>s
 * using configuration information from a single ConfigurationSource.
 * <p>
 * Please refer to the configuration package
 * <a href="package-summary.html#configuration_sources">documentation</a> for complete
 * documentation and useage information.
 *
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class ConfigurationConfigurator {

    /**
     * Creates new ConfgurationSource instances based on the parameters specified
     * in the specified ConfigurationSource.
     * <p>
     * By default, this source will also be added to the ConfigurationService.  If
     * this is not the desired behaviour, please use the overloaded method.
     *
     * @param service The ConfigurationService to initialize.
     * @param source ConfigurationSource containing parameters to use to initialize other sources.
     */
    public static void configureSources( ConfigurationService service, ConfigurationSource source ) throws ConfigurationException {

        configureSources( service, source, true );
    }

    /**
     * Creates new ConfgurationSource instances based on the parameters specified
     * in the specified ConfigurationSource.  Also accepts a boolean to indicate
     * whether this source should be added to the ConfigurationService as well.
     *
     * @param service The ConfigurationService to initialize.
     * @param source ConfigurationSource containing parameters to use to initialize other sources.
     * @param addToService if true, the specified source will be added to the ConfigurationService.
     */
    public static void configureSources( ConfigurationService service, ConfigurationSource source, boolean addToService ) throws ConfigurationException {

        String delimiter = service.getDelimiter();

        //First, add this source to the ConfigurationService, (even if it is not supose to be).
        //We will remove it later if neccessary, but we add it now to 'read' the data it contains.
        service.addConfigurationSource( source );

        Properties sources;
        String sourceName = "";
        ArrayList sourceNames = new ArrayList();

        try {
            sources = service.getValues( "source" );
            boolean run = true;
            int sourceNumber = 0;

            //Load the names of the sources, in order.
            while( run ) {
                sourceNumber++;
                sourceName = sources.getProperty( "source" + sourceNumber );
                if( sourceName != null ) {
                    sourceNames.add( sourceName );
                }
                else {
                    run = false;
                }
            }

            if( sourceNames.size() == 0 ) {
                throw new NotFoundException( "Parameter source.source1 not found.  No sources loaded." );
            }
        }
        catch( NotFoundException nfe ) {
            throw new ConfigurationException( "No Sources defined the specified ConfigurationSource.", nfe );
        }

        String sourceClass = "";
        Properties sourceProperties;
        ConfigurationSource sourceInstance;
        ArrayList sourceInstances = new ArrayList();

        Iterator sourceNamesEnum = sourceNames.iterator();

        while( sourceNamesEnum.hasNext() ) {

            try {

                sourceName = (String) sourceNamesEnum.next();
                sourceProperties = service.getAllValues( "source" + delimiter + sourceName );

                //Create and initialize the new class.
                sourceClass = sourceProperties.getProperty( "class" );
                sourceInstance = (ConfigurationSource) Class.forName( sourceClass ).newInstance();
                sourceInstance.initialize( service, sourceProperties );

                sourceInstances.add( sourceInstance );
            }
            catch( NotFoundException nfe ) {
                _log.error( "ConfigurationSource: " + sourceName + " does not properly specify a \"class\" parameter." );
            }
            catch( ClassCastException cce ) {
                _log.error( "The specified class does not implement the ConfigurationSource interface", cce );
            }
            catch( ClassNotFoundException cnfe ) {
                _log.error( "The specified class (" + sourceClass + ") could not be found for source: " + sourceName, cnfe);
            }
            catch( InstantiationException ie ) {
                _log.error( "Error instantiating class: " + sourceClass + " for source: " + sourceName, ie );
            }
            catch( IllegalAccessException iae ) {
                _log.error( "Error instantiating class: " + sourceClass + " for source: " + sourceName, iae );
            }
        }

        //Remove the source if it was not supose to be added.
        //We need to do this before we add the new sources to insure
        //there will be no naming collisions.
        if( !addToService ) {
            service.removeConfigurationSource( source );
            service.refresh();
        }

        //Add the new sources
        int numSource = sourceInstances.size();
        for( int index = 0; index < numSource; index++ ) {
            service.addConfigurationSource( (ConfigurationSource) sourceInstances.get( index ) );
        }
    }

    //***************************************************************
    // Variables
    //***************************************************************

	/** Logger instance */
	private static Log _log = LogFactory.getLog( ConfigurationConfigurator.class );

}
//EOF
