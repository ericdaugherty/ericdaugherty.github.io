/******************************************************************************
 * $Workfile: PropertyFileSource.java $
 * $Revision: 2 $
 * $Author: Edaugherty $
 * $Date: 5/21/02 8:23p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration;

//Java imports
import java.io.*;
import java.util.*;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//Local imports
import com.ericdaugherty.lib.error.ConfigurationException;

/**
 * Provides an implementation of the ConfigurationSource interface to
 * read configuration information from a standard Java .properties file.
 * <p>
 * This source has three configurable parameters.  These parameters my be
 * configured either though the setXXX methods, or by passing them in to
 * the initialize() method.  The parameters are:
 * <ul>
 *   <li>"file" (required) - The (full) name of the file to load.
 *   <li>"refreshseconds" - (optional, defaults to 60) The time to wait between checks of the file to determine if it should be reloaded.
 *       If this parameter is set to -1, the thread will not start.  Otherwise, the thread will sleep for
 *       the specified number of seconds between checks.
 *   <li>"delimiter" (optional, defaults to ".") - Allows a delimiter other than "." to be used.  This is not reccomended
 *       but is included for cases where the "." charecter is not an acceptable key delimiter.
 *
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class PropertyFileSource extends FileSource {

    //***************************************************************
    // ConfigurationSource Implementation Methods
    //***************************************************************

    /**
     * Initializes the parameters and verifies that the specified file name is valid.
     * <p>
     * Any parameters specified in this properties file will overwrite any properties
     * previously set using the accessor methods.
     *
     * @param service reference to the default or named singleton instance of the ConfigurationService
     * @param properties instance containing any source specific configuration parameters.
     *
     * @exception ConfigurationException thrown if the source cannot successfully be initialized with
     * the provided parameters.
     */
    public void initialize( ConfigurationService service, Properties properties ) throws ConfigurationException {

        String delimiter = properties.getProperty( DELIMITER );
        if( delimiter != null && !delimiter.trim().equals( "" ) ) {
            _delimiter = delimiter;
        }

        super.initialize( service, properties );
    }

    /**
     * Provides access to the parameters defined by the configuration
     * source implementation.
     *
     * @exception ConfigurationException thrown if there is an error loading the Properties File.
     */
    public ConfigurationData getConfigurationData() throws ConfigurationException {

        if( _file == null ) {
            throw new ConfigurationException( "PropertyFileSource must be initialized before calling getConfigurationData()" );
        }

        //Update the time this file was last read.
        _timeStamp = _file.lastModified();

        Collection keyData = new ArrayList();
        Collection valueData = new ArrayList();

        Properties loadedProperties = new Properties();
        try {
            loadedProperties.load( new FileInputStream( _file ) );
        }
        catch( IOException ioe ) {
            throw new ConfigurationException( "Unable to load the PropertyFile: " + _file.getAbsolutePath(), ioe );
        }

        boolean defaultDelimiter = _service.getDelimiter().equals( _delimiter );

        Enumeration keys = loadedProperties.keys();
        String key;
        String parsedKey;

        while( keys.hasMoreElements() ) {
            key = (String) keys.nextElement();

            //If the delimiter for this file is different than the ConfigurationService's
            //default delimiter, parse this key to the appropriate delmitier.
            if( !defaultDelimiter ) {
                parsedKey = _service.convertDelimiter( key, _delimiter );
            }
            else {
                parsedKey = key;
            }

            keyData.add( parsedKey );
            valueData.add( loadedProperties.getProperty( key ) );
        }

        ConfigurationData data = new ConfigurationData( keyData, valueData );

        return data;
    }

    //***************************************************************
    // Other Public Methods
    //***************************************************************

    /**
     * Sets the delimiter to use to parse the keys.
     * <p>
     * If this parameter is not specified, "." is used.
     *
     * @param delimiter to use to parse the file.
     */
    public void setDelimiter( String delimiter ) {
        _delimiter = delimiter;
    }

    //***************************************************************
    // Variables
    //***************************************************************

    /** Delimiter to use to parse the keys. */
    private String _delimiter = ".";

    /** Logger instance */
	private static Log _log = LogFactory.getLog( PropertyFileSource.class );

    //***************************************************************
    // Constants
    //***************************************************************

    private static final String DELIMITER = "delimiter";

}

//EOF
