/******************************************************************************
 * $Workfile: ConfigurationService.java $
 * $Revision: 2 $
 * $Author: Edaugherty $
 * $Date: 5/21/02 8:23p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration;

//Java imports
import java.util.*;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//Local imports
import com.ericdaugherty.lib.error.*;

/**
 * Centralized configuration manager.  This class should be the single
 * access point for all configuration information in a given application.
 * <p>
 * This class provides caching and dynamic configuration updates using
 * multiple extendable sources.
 * <p>
 * Please refer to the configuration package
 * <a href="package-summary.html#package_description">documentation</a> for complete
 * documentation and useage information.
 *
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class ConfigurationService {

    //***************************************************************
    // Constructor
    //***************************************************************

	/**
	 * Private Constructor to prohibit any unauthorized access to this class.
	 * This class is implemented as a singleton, so we do not want any
	 * other calling methods to attempt to instantiate a new instance
	 * of this class.
	 */
	private ConfigurationService() {

		_log.debug( "Creating default instance of ConfigurationService." );

		initializeInstance();
	}

    /**
     * Private Constructor to prohibit any unauthorized access to this class.
     * This class can be used as a Named Singleton.  This allows multiple
     * seperate ConfigurationServices to exist at once.
     */
    private ConfigurationService( String instanceName ) {

        _log.debug( "Creating named instance (" + instanceName + ") of ConfigurationService." );

        /** Add this instance to the map */
        _namedInstances.put( instanceName, this );

        initializeInstance();
    }

	//***************************************************************
    // Public Methods
    //***************************************************************

	//***************************************************************
    // Static Singleton Access Methods

	/**
	 * Provides access to the default singleton instance of ConfigurationService.
	 * If the singleton instance does not exist, a new one is created
	 * using the default settings.
	 *
	 * @return singleton instance of the ConfigurationService
	 */
	public synchronized static ConfigurationService getInstance() {
		if( _instance == null ) {
            _instance = new ConfigurationService();
        }
        return _instance;
	}

    /**
     * Provides access to a named singleton instance of ConfigurationService.
     * If the singleton instance does not exist, a new one is created
     * using the default settings.
     *
     * @param instanceName the name of the instance to retrieve or create.
     * @return singleton instance of the ConfigurationService
     */
    public synchronized static ConfigurationService getInstance( String instanceName ) {

        ConfigurationService instance = (ConfigurationService) _namedInstances.get( instanceName );

        if( instance == null ) {
            instance = new ConfigurationService( instanceName );
        }
        return instance;
    }

	//***************************************************************
    // Instance Helper Methods

	/**
	 * Parses the first node name from the begining of the string.
	 * If the delimiter could not be found in the string, the
	 * original key is returned.
	 *
	 * @param key String to parse
	 * @return first (or only) node in the string
	 */
	public String parseFirstNode( String key ) {
		int index = key.indexOf( getDelimiter() );

		if( index == -1 ) {
			return key;
		}
		else {
			return key.substring( 0, index );
		}
	}

	/**
	 * Parses the last name from the end of the string.  If the
	 * delimiter could not be found in the string, the original key
	 * is returned.
	 *
	 * @param key String to parse
	 * @return last (or only) node in the string
	 */
	public String parseLastNode( String key ) {
		int index = key.lastIndexOf( getDelimiter() );
		int length = getDelimiter().length() - 1;

		if( index == -1 ) {
			return key;
		}
		else {
			return key.substring( ( index + length ) + 1 );
		}
	}

	/**
	 * Removes the last name from the end of the string and returns
	 * the begining of the string up to (but not including) the last
	 * delimiter.  If there is only one node in the string, an empty
	 * string is returned.
	 *
	 * @param key String to parse
	 * @return nodes 1 to (n - 1), or and empty string if there is only one node in the string.
	 */
	public String parseFirstNodes( String key ) {
		int index = key.lastIndexOf( getDelimiter() );

		if( index == -1 ) {
			return "";
		}
		else {
			return key.substring( 0, index );
		}
	}

	/**
	 * Removes the first name from the begining of the string and returns
	 * the string begining with the second node name through the end of
	 * the string.  If there is only one node in the string, an empty
	 * string is returned.
	 *
	 * @param key String to parse
	 * @return nodes 2 to n, or and empty string if there is only one node in the string.
	 */
	public String parseLastNodes( String key ) {
		int index = key.indexOf( getDelimiter() );
		int length = getDelimiter().length() - 1;

		if( index == -1 ) {
			return "";
		}
		else {
			return key.substring( ( index + length ) + 1 );
		}
	}

	/**
	 * Converts the specified key with the specified delimiter into a
	 * key that uses the ConfigurationService delimiter.
	 * <p>
	 * This is useful when loading a property from a source that
	 * uses a delimiter that is different from the ConfigurationService's delimiter.
	 *
	 * @param sourceKey the key to convert
	 * @param sourceDelimiter the delimiter used by the source key.
	 * @return the new key with the correct delimiter
	 */
	public String convertDelimiter( String sourceKey, String sourceDelimiter ) {

		String serviceDelimiter = getDelimiter();

		//If the delimiters are the same, or if there is no delimiter
		//in the key, just return the original key.
		if( serviceDelimiter.equals( sourceDelimiter ) ||
			sourceKey.indexOf( serviceDelimiter ) != -1 ) {
			return sourceKey;
		}
		//Convert the key
		else {
			return convertDelimiter( sourceKey, sourceDelimiter, serviceDelimiter );
		}
	}

	//***************************************************************
    // Initialization/Refresh Methods

	/**
	 * Provides access to the currently defined ConfigurationSources.
	 *
	 * @return array of ConfigurationSource instances used by this class
	 */
	public synchronized ConfigurationSource[] getConfigurationSources() {
		ConfigurationSource[] retval = new ConfigurationSource[_sources.size()];
		retval = (ConfigurationSource[]) _sources.toArray( retval );
		return retval;
	}

	/**
	 * Adds the parameters from a ConfigurationSource to the cached configuration information.
	 * Combines the configuration data from the specified ConfigurationSource
	 * with the existing tree.  However, any values that have already been
	 * defined will NOT be overwritten with new values.  Once a value is
	 * defined, it can not be changed by a 'new' ConfigurationSource.
     * However, new values that 'override' old values, such as more
     * specific environment variables will overwrite the old values, as expected.
	 *
	 * @param source the source containing the parameters to add.
     *
     * @throws ConfigurationException if there is an error adding the source.
	 */
    public synchronized void addConfigurationSource( ConfigurationSource source ) throws ConfigurationException {
		_log.debug( "Adding Configuration Source: " + source.getClass().getName() );
        addConfigurationSourceHelper( source );
    }

	/**
	 * This method removes a specific configuration source from the list of
	 * sources, and removes all of it's values from the configuration data.
     * <p>
     * This method removes the specified source without causing any problems
     * acessing other configuration information, so it may be safely called
     * in a 'live' environment.
     * <p>
     * This method removes all the values, but does not clean up empty nodes from the tree.
     * These nodes should not cause any problem, although repeated adds and removes
     * may create extra memory useage and slow down some operations over time.
     * <p>
     * It should also be noted that any cases where this source contained a value
     * that 'overrode' another source, such as environment variables, this sources
     * variable will be removed, but the other sources 'overridden' value will NOT
     * be restored.  To restore the overridden values, call the refresh method.
     *
     * @param source a reference to the SAME INSTANCE that was passed to
	 * the addConfigurationSource() method.
	 */
	public synchronized void removeConfigurationSource( ConfigurationSource source ) {

        _log.info( "Removing configuration source: " + source.getClass().getName() );

        int sourceNumber = 0;
        try {
            sourceNumber = getSourceNumber( source );
        }
        catch( NotFoundException nfe ) {
            _log.error( "Attempted to remove a ConfigurationSource that does not exist. " + source );
            return;
        }
        Iterator nodeKeys = _configurationData.keySet().iterator();
        String nodeKey;
        ConfigurationNodeStruct node;
        Map nodeData;
        Iterator keys;
        String key;
        ConfigurationDataStruct data;
        Collection nodeChildren;
        List keysToRemove;
        Iterator removeIterator;

        while( nodeKeys.hasNext() ) {

            nodeKey = (String) nodeKeys.next();
            node = (ConfigurationNodeStruct) _configurationData.get( nodeKey );

            nodeData = node.data;
            keys = nodeData.keySet().iterator();
            keysToRemove = new ArrayList();

            //Generate a list of keys to remove from the data map.
            while( keys.hasNext() ) {
                key = (String) keys.next();
                data = (ConfigurationDataStruct) nodeData.get( key );
                if( data.sourceNumber == sourceNumber ) {
                    keysToRemove.add( key );
                }
            }

            //Remove the keys.
            removeIterator = keysToRemove.iterator();
            while( removeIterator.hasNext() ) {
                nodeData.remove( (String) removeIterator.next() );
            }
        }
        _sources.remove( source );
	}

    /**
     * This method allows <a href="ConfigurationSource.html">ConfigurationSource</a>
     * implementations to notify the ConfigurationService when the configuration data
     * in that source has been updated.
     * <p>
     * This allows individual ConfigurationSources to initiate updates instead of waiting for
     * the ConfigurationService to call the refresh() method on the
     * <a href="ConfigurationSource.html">ConfigurationSource</a>.
     * <p>
     * This is the prefered method to 'update' configuration in a live environment.  It will
     * not cause any unexpected <code>NotFoundExceptions</code> to be thrown.  This method will make all
     * additions/updates and removes.  However, it has the same constraint as the
     * removeConfigurationSource(), which is that any previously 'overridden' value
     * will not be restored in cases where the override variable is removed.  To resolve this
     * case, simply call the refresh method after this call.
     *
     * @param source the ConfigurationSource that has updated configuration data.
     */
    public synchronized void updateConfigurationSource( ConfigurationSource source ) throws ConfigurationException {
        _log.debug( "Updating Configuration Source: " + source.getClass().getName() );

        if( _sources.contains( source ) ) {
            addConfigurationSourceHelper( source, true );
        }
        else {
            _log.info( "updateConfigurationSource called for a source that was not added to ConfigurationService.  Ignoring." ) ;
        }
    }

	/**
	 * Convience method to call updateConfigurationSource() on each source defined
     * in the system.  In order to insure that all collisions are resolved, including
     * the adding/removing of override variables, this method can be called twice.
	 */
    public synchronized void refresh() throws ConfigurationException {

		_log.info( "Configuration Information is being refreshed." );

        //Cache the old config sources before they are 'refreshed'.
        List oldConfigSources = _sources;

        Iterator configSources = oldConfigSources.iterator();
        ConfigurationSource source;

        //Refresh each source.
        while( configSources.hasNext() ) {
            source = (ConfigurationSource) configSources.next();
            updateConfigurationSource( source );
        }
    }

    /**
     * Forces the cache of configuration information to be flushed and
     * reloaded from the ConfigurationSource instances.
     * <p>
     * This operation can be expensive, and should only be called when
	 * absolutely neccessary.
	 * <p>
     * This method also may force the ConfigurationSource to be in a state without
     * valid data.  There is no mechanism to prohibit the system from accessing the source
     * during this period of time and getting NotFoundExceptions for keys that are being
     * 'refreshed'.  Because of this, use of this method is HIGHLY DISCOURAGED.
     * The prefered alternative is to have the sources update themselves, or an external
     * entity update the sources one at a time using the updateConfigurationSource() method.
     * However, if sources have been removed, or data from a source has been removed, this
     * method must be used.
	 */
    public synchronized void fullRefresh() throws ConfigurationException {

		_log.info( "Configuration Information is being flushed and reloaded." );

        //Cache the old config sources before they are 'refreshed'.
        List oldConfigSources = _sources;

        //Refresh the internal data structures
        initializeInstance();

        Iterator configSources = oldConfigSources.iterator();
        ConfigurationSource source;

        //Refresh each source.
        while( configSources.hasNext() ) {
            source = (ConfigurationSource) configSources.next();
            addConfigurationSource( source );
        }
    }

    /**
     * This method discards the current configuration information and
     * reinitializes the singleton with the default delimiter.  ALL
     * EXISTING CONFIGURATION WILL BE LOST.  This should be used
     * with great care as it may cause unexpected results.
     * <p>
     * After this method is called, all configuration sources will have
     * to be re-added.
     */
    public synchronized void initialize() {

        _log.info( "Re-Initializing ConfigurationService.  All exising information has been discarded." );

        initializeInstance();
    }

    /**
     * This method discards the current configuration information and
     * reinitializes the singleton with the specified delimiter.  ALL
     * EXISTING CONFIGURATION WILL BE LOST.  This should be used
     * with great care as it may cause unexpected results.
     * <p>
     * After this method is called, all configuration sources will have
     * to be re-added.
     * <p>
     * This method should only be called from a 'startup class'.
     *
     * @param delimiter the delimiter to use to seperate the node names in the keys.
     */
    public synchronized void initialize( String delimiter ) {

        _log.info( "Initializing ConfigurationService with delimiter: " + delimiter + ".  All exising information has been discarded." );

        initializeInstance();
        _delimiter = delimiter;
    }

	//***************************************************************
    // Instance Parameter Access Methods

	/**
	 * Returns the delimiter currently being used to seperate
	 * the nodes in a key.
	 *
	 * @return current delimiter
	 */
	public String getDelimiter() {
		return _delimiter;
	}

	/**
     * Returns the value of the specified key.  The key may reference either
     * a value defined at the root node, or the delimited location of the value in
     * the configuration tree.
     *
     * @param key The key to a specific parameter.
     * @return parameter referenced by the specified key.
     * @exception NotFoundException thrown when the specified key does not map to a parameter.
     */
    public String getValue(String key) throws NotFoundException {

        Map dataStructs = getMap( parseFirstNodes( key ) );

        ConfigurationDataStruct dataStruct = (ConfigurationDataStruct) dataStructs.get( parseLastNode( key ) );

		if( dataStruct != null ) {
			return dataStruct.value;
		}
		else {
			throw new NotFoundException( "The specified key: " + key + " could not be found." );
		}
    }

    /**
     * Returns a <code>java.util.Properties</code> object containing
     * all the values defined at the root node.
     *
     * @return Properties object containing all parameters defined at the root node.
     */
    public Properties getValues() {
		try {
			return getValues( "" );
		}
		catch( NotFoundException nfe ) {
			_log.error( "Root node not found in ConfigurationService.  This should never happen." );
			return new Properties();
		}
    }

    /**
     * Returns a <code>java.util.Properties</code> object containing
     * all the values defined at the node specified by the key.
     *
     * @param key The key to a specific node.
     * @return properties object containing all the parameters referenced by the specified key.
     * @exception NotFoundException thrown when the specified key does not map to a node.
     */
    public Properties getValues(String key) throws NotFoundException {

		Map dataStructs = getMap( key );
        Iterator keys = dataStructs.keySet().iterator();

        Properties properties = new Properties();

        String currentKey;
        String currentValue;
        while( keys.hasNext() ) {
            currentKey = (String) keys.next();
            currentValue = ((ConfigurationDataStruct) dataStructs.get( currentKey ) ).value;
            properties.setProperty( currentKey, currentValue );
        }

        return properties;
    }

    /**
     * Returns a <code>java.util.Properties</code> object containing
     * all the values defined at the root node, and all the values defined
     * in children nodes.  The keys for the values in the child nodes are delimited
     * using the value returned by the 'getDelimiter()' method.
     *
     * @return Properties object containing all parameters defined at the root node.
     */
	public Properties getAllValues() {
		try {
			return getAllValues( "" );
		}
		catch( NotFoundException nfe ) {
			_log.error( "Root node not found in ConfigurationService.  This should never happen." );
			return new Properties();
		}
    }

	/**
     * Returns a <code>java.util.Properties</code> object containing
     * all the values defined at the node specified by the key, and all the
     * values defined in children nodes.  The keys for the values in the
     * child nodes are delimited using the value returned by the 'getDelimiter()'
     * method.
     *
     * @param key The key to a specific node.
     * @return properties object containing all the parameters referenced by the specified key.
     * @exception NotFoundException thrown when the specified key does not map to a node.
     */
	public Properties getAllValues( String key ) throws NotFoundException {

		//Check to make sure the key exists.  This will throw a NotFoundException
		//if the key does not exist.
		getMap( key );

		Properties properties = new Properties();
		buildProperties( key, "", properties );

		if( properties != null ) {
			return properties;
		}
		else {
			throw new NotFoundException( "The specified key: " + key + " could not be found." );
		}
	}

	//***************************************************************
    // Overload Methods

	public String toString() {
		return "ConfigurationService Parameters:\r\n" + _configurationData;
	}

	//***************************************************************
    // Private Methods
    //***************************************************************

    /**
     * Returns a Map containing the keys and values for a specific node.
     *
     * @param key key to a specific node.
     * @return Map object containing all the keys and values for the specified node.
     * @exception NotFoundException thrown when the specified key does not map to a node.
     */
    private Map getMap( String key ) throws NotFoundException {

        ConfigurationNodeStruct node = ( ConfigurationNodeStruct ) _configurationData.get( key );

		if( node != null ) {
			return node.data;
		}
		else {
			throw new NotFoundException( "The specified key: " + key + " could not be found." );
		}
    }

    /**
     * Returns the (1 based) number of the specified source.
     *
     * @param source the source to find the index of.
     * @return the index of the specified source
     * @exception NotFoundException thrown if the specified source does not exist in this ConfigurationService.
     */
    private int getSourceNumber( ConfigurationSource source ) throws NotFoundException {

        int numSources = _sources.size();

        for( int index = 0; index < numSources; index++ ) {
            if( _sources.get( index ) == source ) {
                return index + 1;
            }
        }
        throw new NotFoundException( "Error attempting to find the index of the source: " + source.getClass().getName() + ".  Source Not Found." );
    }

	/**
	 * Checks to see if the specified parameter is an environment
	 * keyword.  This method does NOT check to see if the environment
	 * keyword specified matches the current environment keyworks.
	 * <p>
     * An environment keyword is any string that starts with "env-"
     * (NOT case sensitive).  This method CAN handle null parameters.
     * It will return false if the name parameter is null.
	 * <p>
	 * Environment Keywords are NOT case sensitive.
	 *
	 * @param name node name to test.
	 * @return true if the name is an environment keyword.
	 */
	private boolean isEnvironmentKeyword( String name ) {

        if( name == null || name.equals( "" ) || name.length() < 4  ) {
			return false;
		}
        else if( name.substring( 0, 4 ).equalsIgnoreCase( ENV_PREFIX )  ){
            return true;
        }

		return false;
	}

	/**
	 * Checks to see if the specified keyword matches the current
	 * environment.  If so, true is returned.
	 * <p>
	 * This method CAN handle null parameters.  This method will
	 * return false if the name parameter is null.
	 * <p>
	 * Environment Keywords are NOT case sensitive.
	 *
	 * @param name node name to test.
	 * @return true if the name matches the current environment keyword.
	 */
	private boolean isCurrentEnvironmentKeyword( String name ) {

		if( name == null || name.equals( "" ) ) {
			return false;
		}

		return name.toUpperCase().equals( _currentEnv );
	}

    /**
     * Sets the provided parameter as the environment keyword.
     */
    private void setCurrentEnvironementKeyword( String environmentKeyword ) {

        //Convert to uppercase.
		if( environmentKeyword != null && isEnvironmentKeyword( environmentKeyword ) ) {
			_currentEnv = environmentKeyword.toUpperCase();
			_log.info( "Configuration Environment Keyword set to: " + _currentEnv );
        }
		else {
			_log.info( "Configuration Environment Keyword not set to valid value (" + environmentKeyword + ") defaulting to \"ENV-DEVELOPMENT\"." );
            _currentEnv = ENV_DEVELOPMENT;
		}
    }

	/**
	 * Initializes the current instance of this class.  This method is called
	 * by the constructor and the refresh methods.
	 * <p>
	 * Although it is possible to throw out the singleton instance
	 * and create a new one during refresh, this may leave extra instances
	 * of this 'singleton' if other classes are cashing the reference.
	 * Therefore, it is safer to simply re-initialize the internal
	 * data structures.
	 */
	private void initializeInstance() {

		_log.debug( "Initializing Configuration Source" );

		//Initialize Environment
		setCurrentEnvironementKeyword( System.getProperty( ENV_PROPERTY_NAME ) );

		//Initialize the collections
		_configurationData = Collections.synchronizedMap( new HashMap() );
		_sources = Collections.synchronizedList( new ArrayList() );

		//Create the root node.
		_configurationData.put( "", new ConfigurationNodeStruct() );
	}

    /**
     * Adds a new ConfigurationSource.
     */
    private void addConfigurationSourceHelper( ConfigurationSource source ) throws ConfigurationException {
        addConfigurationSourceHelper( source, false );
    }

    /**
     * Adds or updates a configuration source, depending on the update boolean.
     */
    private void addConfigurationSourceHelper( ConfigurationSource source, boolean update )
            throws ConfigurationException {

        int sourceNumber = -1;
        Object updateObject = _updateNumber.get( source );
        long updateNumber;
        if( updateObject != null ) {
            Long num = (Long) updateObject;
            updateNumber = num.longValue() + 1;
        }
        else {
            updateNumber = 0;
        }
        _updateNumber.put( source, new Long( updateNumber ) );

        if( update ) {
            try {
                sourceNumber = getSourceNumber( source );
            }
            catch( NotFoundException nfe ) {
                throw new ConfigurationException( "Attempting to update ConfigurationSource, but specified source could not be found.", nfe );
            }
        }
        else {
            sourceNumber = _sources.size() + 1;
        }

		ConfigurationData configurationData = source.getConfigurationData();
        ConfigurationDataStruct currentData;
		Iterator sourceKeys = configurationData.getKeys();
        Iterator sourceValues = configurationData.getValues();

        String sourceKey;
		String sourceNodeKey;
		String sourceParameterKey;
		String firstNode;
		ConfigurationNodeStruct newNode;
        ArrayList newKeys = new ArrayList();
        boolean alreadyAdded;

		//Parse each new section in the ConfigurationSource's Map.
		while( sourceKeys.hasNext() ) {

			sourceKey = (String) sourceKeys.next();

            //Verify that there is another value.
            if( !sourceValues.hasNext() ) {
                throw new ConfigurationException( "Unable to parse Configuration Source.  ConfigurationData has more keys than values.");
            }

            //Initialize and fill the currentData instance.
            currentData = new ConfigurationDataStruct();
			currentData.value = (String) sourceValues.next();
            currentData.sourceNumber = sourceNumber;
            currentData.configurationSource = source;
            currentData.updateNumber = updateNumber;

			firstNode = parseFirstNode( sourceKey );

			//Check to determine is this is key contains an environment keyword.
            if( isEnvironmentKeyword( firstNode ) ) {
                if( isCurrentEnvironmentKeyword( firstNode) ) {
                    //If it matches the current env keyword, add it.
                    sourceKey = parseLastNodes( sourceKey );
                    currentData.isEnvironmentParameter = true;
                }
                else {
                    //If it is an Env Keyword, but not the current env, skip the parameter.
                    continue;
                }
            }

			sourceNodeKey = parseFirstNodes( sourceKey );
			sourceParameterKey = parseLastNode( sourceKey );

            //If this node exists, merge this key into the existing keys.
			if( _configurationData.containsKey( sourceNodeKey ) ) {
                //If we are in update mode, and this key has already
                //been added IN THIS UPDATE, set the alreadyAdded flag.
                alreadyAdded = false;
                if( update ) {
                    alreadyAdded = newKeys.contains( sourceKey );
                }

                mergeValues( (ConfigurationNodeStruct) _configurationData.get( sourceNodeKey ), sourceParameterKey, currentData, update, alreadyAdded );
            }
            else {
                newNode = new ConfigurationNodeStruct();
                newNode.data.put( sourceParameterKey, currentData );
                _configurationData.put( sourceNodeKey, newNode );
            }

            //If we are in update mode, we need to enforce the rule that later keys do not overwrite
            //earlier keys, unless the later key is an env variable and the earlier one is not.
            //mergeValues can not enforce this without this information about whether this key has been
            //added already during this update because it does not know if
            //the key already exists for this source from the initial add or this update.
            if( update ) {
                newKeys.add( sourceKey );
            }

			//Update the Map of Child sections with the new section that was
			//added.  This method will recurse, so we don't need to worry about
			//whether this node has an existing child or not.
			addChildNode( sourceNodeKey );
		}

        //Add this configuration source to the list so it can be refreshed,
        //unless we are just updating the source.
        if( !update ) {
            _sources.add( source );
        }

        //If we are in update mode, remove all 'orphaned' values.
        if( update ) {
            Iterator nodeValues = _configurationData.values().iterator();
            ConfigurationNodeStruct node;
            Iterator dataKeys;
            String dataKey;
            ConfigurationDataStruct data;
            ArrayList keysToRemove;
            Iterator keysToRemoveIterator;

            //Parse each node for keys to remove.
            while( nodeValues.hasNext() ) {
                node = (ConfigurationNodeStruct) nodeValues.next();
                dataKeys = node.data.keySet().iterator();
                keysToRemove = new ArrayList();

                //Build a list of the keys to remove from this node.
                while( dataKeys.hasNext() ) {
                    dataKey = (String) dataKeys.next();
                    data = (ConfigurationDataStruct) node.data.get( dataKey );
                    if( data.sourceNumber == sourceNumber &&
                        data.updateNumber < updateNumber ) {
                        keysToRemove.add( dataKey );
                    }
                }

                //Remove the specified keys from this node.
                keysToRemoveIterator = keysToRemove.iterator();
                while( keysToRemoveIterator.hasNext() ) {
                    node.data.remove( (String) keysToRemoveIterator.next() );
                }
            }
        }
    }

    /**
     * Adds a new property to the existing Properties instance if and only if
     * it does not already exist in the Properties instance.  If it does
     * exist, the original instance is returned unchanged.
     *
     * @return Properties object containing newly combined values.
     */
    private void mergeValues( ConfigurationNodeStruct node, String key, ConfigurationDataStruct newData, boolean update, boolean alreadyAdded ) {

        Map original = node.data;

        //Check to see if the value exists yet.  If not simply add it.
        if( !original.containsKey( key ) ) {
            original.put( key, newData );
        }
        //A value already exists.  Check rules to determine if new value has
        // priority over old value.
        else {
            ConfigurationDataStruct oldData = (ConfigurationDataStruct) original.get( key );

            //If the new one is an env variable, and the old one is not, it has priority.
            if( !oldData.isEnvironmentParameter && newData.isEnvironmentParameter ) {
                original.put( key, newData );
            }
            //If the old data is from a later source, overwrite it unless the original data
            //is an environment variable and the new one is not.
            else if( oldData.sourceNumber > newData.sourceNumber &&
                ( !oldData.isEnvironmentParameter ||
                  newData.isEnvironmentParameter ) ) {
                original.put( key, newData );
            }
            //If the sources are the same, and we are in update mode, and this parameter
            //has not been updated in this cycle, then we should overwrite the old value.
            else if( oldData.sourceNumber == newData.sourceNumber &&
                     update &&
                     !alreadyAdded) {
                original.put( key, newData );
            }
        }
    }

	/**
	 * This method will insure that the '_nodeChildren' map is kept up
	 * to date when new keys are added.  This node will create 'empty'
	 * parent nodes, if the current parent node does not exist.
	 *
	 * @param key the new 'child' key to be added.
	 */
	private void addChildNode( String key ) {

		String parentKey = parseFirstNodes( key );
        ConfigurationNodeStruct node = (ConfigurationNodeStruct) _configurationData.get( parentKey );
        List childNodes;

		//The parent already exists, so just add the new child to the existing list.
		if( node!= null ) {
            childNodes = node.childNodeNames;

			//Make sure the node does not already exist.  Must check the root
			//explicitly since it has no parent.
			if( !childNodes.contains( key ) && !key.equals( "" ) ) {
				childNodes.add( key );
			}
		}
		//The Parent node does not exist, so we need to add it.
		else {
			//Initialize the 'values' entry for this node if it has no
			//already been initialized
            node = new ConfigurationNodeStruct();

            node.childNodeNames.add( key );
            _configurationData.put( parentKey, node );

			if( !parentKey.equals( "" ) ) {
				addChildNode( parentKey );
			}
		}
	}

	/**
	 * This is a helper method to convert a the delimiter in a key.  This
	 * method performs no validation, and should be called only from the
	 * convertDelimiter() methods.
	 */
	private static String convertDelimiter( String sourceKey, String sourceDelimiter, String targetDelimiter ) {

		StringBuffer newKey = new StringBuffer();
		StringTokenizer tokenizer = new StringTokenizer( sourceKey, sourceDelimiter );

		//Build up the new key.
		while( tokenizer.hasMoreTokens() ) {

			//Append the delimiter for every token except the first.
			if( newKey.length() > 0 ) {
				newKey.append( targetDelimiter );
			}
			newKey.append( tokenizer.nextToken() );
		}

		return newKey.toString();
	}

	/**
	 * This method takes a node and builds a properties object that contains
	 * all the values defined at this node, plus all the properties defined
	 * below this node, with the key being set to the relative 'path' to the
	 * parameters.
	 *
	 * @param key the key for which to build from
	 * @param properties the properties object to build.
	 */
	private void buildProperties( String key, String keyPrefix, Properties properties ) {

		String delimiter = getDelimiter();

		//Node Values and Children
        Properties nodeProperties = null;
		try {
            nodeProperties = getValues( key );
        }
        catch( NotFoundException nfe ) {
            _log.error( "Error loading node: " + key + " in buildProperties.  This error should never occur." );
            nodeProperties = new Properties();
        }
        ConfigurationNodeStruct node = (ConfigurationNodeStruct) _configurationData.get( key );
		Iterator childNodes = node.childNodeNames.iterator();

		//Add all of this node's properties to the main property instance.
		Enumeration keys = nodeProperties.keys();
		String currentKey;
		String newKey;
		if( keyPrefix.equals( "" ) ) {
			newKey = keyPrefix;
		}
		else {
			newKey = keyPrefix + delimiter;
		}

		while( keys.hasMoreElements() ) {
			currentKey = (String) keys.nextElement();
			properties.setProperty( newKey + currentKey, nodeProperties.getProperty( currentKey ) );
		}

		String nextChildNode;
		//Build up each Child.
		while( childNodes.hasNext() ) {
			nextChildNode = (String) childNodes.next();
			buildProperties( nextChildNode, newKey + parseLastNode( nextChildNode ) , properties );
		}
	}

	//***************************************************************
    // Variables
    //***************************************************************

    private String _currentEnv = "";

	/**
	 * Delimiter is used to seperate the nodes in a key.  The default
	 * value is "."
	 */
	private String _delimiter = ".";

	/**
	 * Map of ConfigurationNodeStruct instances.  Each keys in this
     * map is a node.
	 */
	private Map _configurationData;

    private Map _updateNumber = Collections.synchronizedMap( new HashMap() );

	/**
	 * List of ConfigurationSource instances.  This list is used when
	 * a refresh() occurs and the configuration is reloaded.
	 */
	private List _sources;

    /** Map of Named Singleton instances. */
    private static Map _namedInstances = new HashMap();

	/** Default Singleton instance of this class */
	private static ConfigurationService _instance = null;

	/** Logger instance */
	private static Log _log = LogFactory.getLog( ConfigurationService.class );

	//***************************************************************
    // Constants
    //***************************************************************

	private static final String ENV_PROPERTY_NAME = "environment";
    private static final String ENV_PREFIX = "env-";
    private static final String ENV_DEVELOPMENT = "ENV-DEVELOPMENT";

    /**
     * This class represents the information needed at each node.
     * It contains a Map of they keys/values at the node, and
     * a Collection of child nodes.
     * <p>
     * The data map contains a Strings as keys, and ConfigurationDataStruct
     * objects as values.  The childNodeNames list contains Strings
     * representing the child node names.
     */
    private class ConfigurationNodeStruct {

        Map data = Collections.synchronizedMap( new HashMap() );
        List childNodeNames = Collections.synchronizedList( new ArrayList() );
    }

    /**
     * Inner class that just holds a single configuration value and associated
     * parameters.
     */
    private class ConfigurationDataStruct {

        boolean isEnvironmentParameter = false;
        int sourceNumber;
        ConfigurationSource configurationSource;
        String value;
        long updateNumber;
    }
}
//EOF