/******************************************************************************
 * $Workfile: FileSource.java $
 * $Revision: 2 $
 * $Author: Edaugherty $
 * $Date: 5/21/02 8:23p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration;

//Java imports
import java.io.File;
import java.util.Properties;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//Local imports
import com.ericdaugherty.lib.error.ConfigurationException;

/**
 * Abstract class that provides common functionality for all sources that load
 * configuration information from a file.
 * <p>
 * Classes that extends this class must provide implementations of the
 * the ConfigurationSource interface methods.  Also, if the implementation wishes
 * to utilize to FileWatcher thread, it must call startWatcher() in it's initialize()
 * method.
 *
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public abstract class FileSource implements ConfigurationSource {

    //***************************************************************
    // Public Methods
    //***************************************************************

    /**
     * Allows the ConfigurationSource implementation to be passed parameters from
     * an external class.  This allows ConfigurationSources to be initialized from
     * a configuration source instead of programmatically.
     * <p>
     * All ConfigurationSource implementations should have a default (no parameter) constructor.
     *
     * @param service reference to the default or named singleton instance of the ConfigurationService
     * @param properties instance containing any source specific configuration parameters.
     *
     * @exception ConfigurationException thrown if the source cannot successfully be initialized with
     * the provided parameters.
     */
    public void initialize(ConfigurationService service, Properties properties) throws ConfigurationException {

        _service = service;

        //Load the parameters from the Properties file.
        String fileName = properties.getProperty( FILE_NAME );
        if( fileName != null && !fileName.trim().equals( "" ) ) {
            _fileName = fileName;
        }

        String refreshSeconds = properties.getProperty( REFRESH_SECONDS );
        if( refreshSeconds != null && !refreshSeconds.trim().equals( "" ) ) {
            _refreshSeconds = Long.parseLong( refreshSeconds );
        }

        _source = this;

        //Load the File.
        _file = new File( _fileName );

        if( !_file.exists() ) {
            throw new ConfigurationException( "FileSource unable to load file: " + _file.getAbsolutePath() );
        }

        //Start the watcher thread.
        startWatcher();
    }

    /**
     * Sets the file name to use to open the configuration file.  This
     * setting does not take affect until the initialize method is called.
     *
     * @param fileName name (and path) of the file to load.
     */
    public void setFileName( String fileName ) {
        _fileName = fileName;
    }

    /**
     * Sets the number of seconds the FileWatcher thread should wait between
     * checks of the configuration file.
     * <p>
     * Changes to this parameter will not take affect unless the thread is stoped and restarted.
     * <p>
     * This value can be set to -1 to disable the automatic reloading.
     *
     * @param refreshSeconds the number of seconds to wait between checks of
     * the configuration file.
     */
    public void setRefreshSeconds( long refreshSeconds ) {
        _refreshSeconds = refreshSeconds;
    }

    /**
     * Starts the thread that watches the properties file for changes, if it
     * is not already running.
     */
    public void startWatcher() {

        if( _refreshSeconds > 0 &&
            ( _fileWatcher == null || !_fileWatcher.isAlive() ) ) {
            _log.info( "Starting/Restarting the FileSource FileWatcher thread for file: " + _file.getAbsolutePath() );
            _fileWatcher = new FileWatcher();
            _fileWatcher.start();
        }
        else {
            _log.info( "Attempted to restart the FileSource FileWatcher thread for file: " + _file.getAbsolutePath() + ", but it is still alive." );
        }
    }

    /**
     * Stops the thread that is watching the configuration file for changes.
     */
    public void stopWatcher() {
        _log.info( "Stopping the FileSource FileWatcher thread for file: " + _file.getAbsolutePath() );
        _fileWatcher.stopWatcher();
    }

    //***************************************************************
    // Variables
    //***************************************************************

    protected ConfigurationService _service = null;
    protected File _file = null;
    protected String _fileName = "";
    protected long _refreshSeconds = 60;
    protected long _timeStamp;
    protected ConfigurationSource _source;
    protected FileWatcher _fileWatcher;

    /** Logger instance */
	private static Log _log = LogFactory.getLog( FileSource.class );

    //***************************************************************
    // Constants
    //***************************************************************

    private static final String FILE_NAME = "file";
    private static final String REFRESH_SECONDS = "refreshseconds";


    //***************************************************************
    // Inner Classes
    //***************************************************************

    /**
     * Watches specified file for changes.  If a change occurs,
     * ConfigurationService.updateConfigurationSource() is called.
     */
    protected class FileWatcher extends Thread {

        public FileWatcher() {
            setDaemon(true);
            _delay = _refreshSeconds * 1000;
        }

        /**
         * Watches the File for changes.
         */
        public void run() {

            long lastModified;

            while( _run ) {

                try {
                    sleep( _delay );
                }
                catch( InterruptedException ie ) {
                    _log.warn( "FileSource Watcher Thread interrupted." );
                }

                if( !_file.exists() ) {
                    if( !_alreadyWarned ) {
                        _log.error( "File Watcher unable to watch file: " + _file.getAbsolutePath() + " because the file does not exist." );
                    }
                    //Don't continue this loop, but go to sleep again
                    //incase the file is replaced.
                    continue;
                }
                else {
                    _alreadyWarned = false;
                }

                lastModified = _file.lastModified();
                if( lastModified > _timeStamp ) {
                    _log.info( "File: " + _file.getAbsolutePath() + " changed.  Reloading Configuration Data." );
                    try {
                        _service.updateConfigurationSource( _source );
                        _timeStamp = lastModified;
                    }
                    catch( ConfigurationException ce ) {
                        _log.error( "Unable to reload updated File: " + _file.getAbsolutePath() + ".  Configuration Exception Occurred.", ce );
                    }
                }
            }
        }

        public void stopWatcher() {
            _run = false;
        }


        //***************************************************************
        // Inner Variables
        //***************************************************************

        /** Indicates whether this thread should continue to run.  Set to false to stop the thread */
        private boolean _run = true;

        /** Number of milliseconds to wait between each check */
        private long _delay;

        /**
         * Keeps track of whether a log file entry has been made indicating
         * that the file does not exist.
         */
        private boolean _alreadyWarned = false;
    }
}
//EOF
