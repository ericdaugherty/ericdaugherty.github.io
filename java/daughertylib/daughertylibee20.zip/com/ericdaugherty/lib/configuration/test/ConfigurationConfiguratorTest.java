/******************************************************************************
 * $Workfile: ConfigurationConfiguratorTest.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 5/21/02 8:25p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration.test;

//Java imports
import java.io.*;
import java.util.Properties;

//jUnit imports
import junit.framework.*;

//Local imports
import com.ericdaugherty.lib.configuration.*;

/**
 * Tests the <a href="../ConfigurationConfigurator.html">ConfigurationConfigurator</a> class.
 *
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class ConfigurationConfiguratorTest extends TestCase {

    public ConfigurationConfiguratorTest( String name ) {
        super( name );
    }

    /**
     * Test basic operation of PropertyFileSource, and automatic reload functionality.
     */
    public void testConfigurator() {

        try {
            Properties sourceProperties1 = new Properties();

            sourceProperties1.setProperty( "root1", "rootvalue1" );
            sourceProperties1.setProperty( "root2", "rootvalue2" );
            sourceProperties1.setProperty( "node1.node2.node3.root1", "rootvalue11" );
            sourceProperties1.setProperty( "node1.node2.node3.root2", "rootvalue22" );

            FileOutputStream fileOutputStream = new FileOutputStream( "temp1.properties" );

            sourceProperties1.store( fileOutputStream, "" );

            fileOutputStream.close();

            Properties sourceProperties2 = new Properties();

            sourceProperties2.setProperty( "root1", "wrongvalue" );
            sourceProperties2.setProperty( "root11", "rootvalue11" );
            sourceProperties2.setProperty( "root22", "rootvalue22" );
            sourceProperties2.setProperty( "node1.node2.node3.root11", "rootvalue111" );
            sourceProperties2.setProperty( "node1.node2.node3.root22", "rootvalue222" );

            fileOutputStream = new FileOutputStream( "temp2.properties" );

            sourceProperties2.store( fileOutputStream, "" );

            fileOutputStream.close();


            MemorySource memorySource = new MemorySource();

            memorySource.setValue( "source.source1", "propsource" );
            memorySource.setValue( "source.propsource.class", "com.ericdaugherty.lib.configuration.PropertyFileSource" );
            memorySource.setValue( "source.propsource.file", "temp1.properties" );
            memorySource.setValue( "source.source2", "propsource2" );
            memorySource.setValue( "source.propsource2.class", "com.ericdaugherty.lib.configuration.PropertyFileSource" );
            memorySource.setValue( "source.propsource2.file", "temp2.properties" );

            ConfigurationService service = ConfigurationService.getInstance();
            service.initialize();
            ConfigurationConfigurator.configureSources( service, memorySource );

            assertEquals( "rootvalue1", service.getValue( "root1" ) );
            assertEquals( "rootvalue2", service.getValue( "root2" ) );
            assertEquals( "rootvalue11", service.getValue( "node1.node2.node3.root1" ) );
            assertEquals( "rootvalue22", service.getValue( "node1.node2.node3.root2" ) );
            assertEquals( "rootvalue11", service.getValue( "root11" ) );
            assertEquals( "rootvalue22", service.getValue( "root22" ) );
            assertEquals( "rootvalue111", service.getValue( "node1.node2.node3.root11" ) );
            assertEquals( "rootvalue222", service.getValue( "node1.node2.node3.root22" ) );

        }
        catch( Throwable t ) {
            assertTrue( "Error occured while testing PropertyFileSource: " + t.getMessage(), false );
        }
    }
}
//EOF
