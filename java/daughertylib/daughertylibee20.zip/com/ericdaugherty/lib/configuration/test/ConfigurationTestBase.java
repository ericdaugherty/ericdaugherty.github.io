/******************************************************************************
 * $Workfile: ConfigurationTestBase.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 5/09/02 2:51p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration.test;

//Java imports
import java.util.Properties;

//jUnit imports
import junit.framework.*;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//Local imports
import com.ericdaugherty.lib.configuration.*;
import com.ericdaugherty.lib.error.*;

/**
 * Provides 'setup' for Configuration Tests
 */
public class ConfigurationTestBase extends TestCase
{	
	public ConfigurationTestBase( String name ) {
		super( name );
	}
	
	protected void setUp() {

        _log.debug( "Setting up ConfigurationTestbase" );

        try {

            //Define the configuration 'environment'
            System.setProperty( "environment", "env-myenvironment" );
            ConfigurationService service = ConfigurationService.getInstance();

            service.initialize();

            _testSource = new MemorySource();
            _testSource2 = new MemorySource();

            //Setup Root Values
            _testSource.addValue( "root1", "rootvalue1" );
            _testSource.addValue( "rOOt1", "rootvalue1caps" );
            _testSource.addValue( "root2", "rootvalue2" );
            _testSource.addValue( "Root2", "rootvalue2caps" );
            _testSource.addValue( "root1", "Source 1 Order failed" );

            //Try to overwrite prev set values.
            _testSource2.addValue( "root1", "Source2 Overwrote Source1" );
            _testSource2.addValue( "root2", "Source2 Overwrote Source1" );

            String delimiter = service.getDelimiter();

            //Test the environment parameters
            _testSource.addValue( "envroot1", "genericrootvalue1" );
            _testSource.addValue( "env-system" + delimiter + "envroot1", "env-system-rootvalue1" );
            _testSource.addValue( "env-myenvironment" + delimiter + "envroot1", "rootvalues1" );

            _testSource.addValue( "env-myenvironment" + delimiter + "envroot2", "rootvalues2" );
            _testSource.addValue( "env-system" + delimiter + "envroot2", "env-system-rootvalue2" );
            _testSource.addValue( "envroot2", "genericrootvalue2" );

            _testSource.addValue( "env-system" + delimiter + "envroot3", "env-system-rootvalue3" );
            _testSource.addValue( "envroot3", "genericrootvalue3" );
            _testSource.addValue( "env-myenvironment" + delimiter + "envroot3", "rootvalues3" );

            _testSource.addValue( "envroot4", "genericrootvalues4" );

            String node3 = "nodelevel1" + delimiter + "nodelevel2" + delimiter + "nodelevel3";

            _testSource.addValue( node3 + delimiter + "root1", "rootvalue11" );
            _testSource.addValue( node3 + delimiter + "root2", "rootvalue22" );

            _testSource.addValue( node3 + delimiter + "envroot1", "genericrootvalue11" );
            _testSource.addValue( "env-system" + delimiter + node3 + delimiter + "envroot1", "env-system-rootvalue11" );
            _testSource.addValue( "env-myenvironment" + delimiter + node3 + delimiter + "envroot1", "rootvalues11" );

            _testSource.addValue( "env-myenvironment" + delimiter + node3 + delimiter + "envroot4", "rootvalues44" );

            ConfigurationService.getInstance().addConfigurationSource( _testSource );

            //This is to test that the original values are not overwritten.
            _testSource2.addValue( "root1", "wrong" );
            _testSource2.addValue( node3 + delimiter + "root1", "wrong" );

            //This is to make sure new values are added
            _testSource2.addValue( "root3", "rootvalue3" );
            _testSource2.addValue( node3 + delimiter + "root3", "rootvalue33" );

            _testSource2.addValue( "env-myenvironment" + delimiter + "envroot4", "rootvalues4" );

            _testSource2.addValue( node3 + delimiter + "envroot4", "genericrootvalues44" );

            ConfigurationService.getInstance().addConfigurationSource( _testSource2 );
        }
        catch( ConfigurationException configurationException ) {
            _log.fatal( "Error Setting up ConfigurationTestBase.", configurationException );
        }
	}

	protected void tearDown() {
        ConfigurationService.getInstance().removeConfigurationSource( _testSource );
		ConfigurationService.getInstance().removeConfigurationSource( _testSource2 );
	}

	//***************************************************************
    // Variables
    //***************************************************************

	protected static MemorySource _testSource;
	protected static MemorySource _testSource2;

	protected Log _log = LogFactory.getLog( ConfigurationTestBase.class );

	//***************************************************************
    // Constants
    //***************************************************************

	protected static final String KEY_1 = "abc.123.456.789";
	protected static final String KEY_1_FIRST_NODE = "abc";
	protected static final String KEY_1_FIRST_NODES = "abc.123.456";
	protected static final String KEY_1_LAST_NODE = "789";
	protected static final String KEY_1_LAST_NODES = "123.456.789";

	protected static final String KEY_2 = "ghskle";

}
//EOF