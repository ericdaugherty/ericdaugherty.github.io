/*
 * $Archive: /ericdaughertylib/src/com/ericdaugherty/lib/service/WebConfigurationService.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 1/09/02 10:48a $
 *
 * (c) 2000 Eric Daugherty
 */

package com.ericdaugherty.lib.service;

//Java imports

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//Local imports
import com.ericdaugherty.lib.error.SystemException;

/**
 * This class provides access to all configuration information
 * defined as env entries in a web.xml deployment descriptor.
 * 
 * @author Eric Daugherty
 */
public class WebConfigurationService extends JndiConfigurationService {
    
    //***************************************************************
    // Constructor
    //***************************************************************

    /**
     * Creates a new instance and calls the initialize method.
     */
    private WebConfigurationService() throws SystemException {
        super( ENV_CONTEXT_NAME );
    }

    //***************************************************************
    // Public Interface
    //***************************************************************
    
    /**
     * Returns the singleton instance of this class.  If the instance
     * has not yet been created, a new instance is created and returned.
     * 
     * @return the EnvEntryConfigurationService singleton instance
     */
    public static synchronized WebConfigurationService getInstance() throws SystemException {
        if( _webConfigurationService == null ) {
            _webConfigurationService = new WebConfigurationService();
        }
        return _webConfigurationService;
    }
    
    //***************************************************************
    // Private Interface
    //***************************************************************
    
    //***************************************************************
    // Variables

    /** Singleton Instance */
    private static WebConfigurationService _webConfigurationService = null;
    
    /** Logger Category for this class.  */
    private static Log _log = LogFactory.getLog( WebConfigurationService.class );

    //***************************************************************
    // Constants
    
    private static final String ENV_CONTEXT_NAME = "java:comp/env";
   
 }
//EOF