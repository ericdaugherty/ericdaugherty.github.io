/*
 * $Archive: /ericdaughertylib/src/com/ericdaugherty/lib/service/EjbConfigurationService.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 1/09/02 10:48a $
 *
 * (c) 2000 Eric Daugherty
 */

package com.ericdaugherty.lib.service;

//java imports

//local imports
import com.ericdaugherty.lib.error.SystemException;

/**
 * This class provides access to all configuration information
 * defined as env entries in an ejb-jar.xml deployment descriptor.
 * 
 * Because each EJB only has access to it's own paramters, each 
 * EJB must use its own instance of this class.  Therefore, this
 * class is NOT implemented as a singleton, and should NOT be shared
 * across EJBs.  Each EJB should create and cache its own instance
 * of this class.
 * 
 * @author Eric Daugherty
 */
public class EjbConfigurationService extends JndiConfigurationService {
	
    //***************************************************************
    // Constructor
    //***************************************************************

    /**
     * Creates a new instance and calls the initialize method.
     */
    public EjbConfigurationService() throws SystemException {
        super( ENV_CONTEXT_NAME );
    }
	    
    //***************************************************************
    // Constants
    
    private static final String ENV_CONTEXT_NAME = "java:comp/env";
   
}
//EOF
