/******************************************************************************
 * $Workfile: JndiConfigurationService.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 3/14/02 9:21a $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are permitted provided 
 * that the following conditions are met:
 * 
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the 
 *   following disclaimer. 
 * 
 *   Redistributions in binary form must reproduce the 
 *   above copyright notice, this list of conditions and 
 *   the following disclaimer in the documentation and/or 
 *   other materials provided with the distribution. 
 * 
 *   Neither the name of Eric Daugherty nor the names of its 
 *   contributors may be used to endorse or promote products 
 *   derived from this software without specific prior written 
 *   permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.service;

//Java imports
//javax.naming has ConfigurationException which collides
//with com.ericdaugherty.lib.error.ConfigurationException,
//so this package is not import with .*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;
import javax.naming.NameClassPair;
import java.util.Hashtable;
import java.util.Properties;

//Local imports
import com.ericdaugherty.lib.error.ConfigurationException;

/**
 * This class provides access to information bound to a JNDI tree.
 * <p>
 * This class provides a nice front end to the code to query configuration
 * parameters from a JNDI server.  It also provides convenience methods to
 * cast the values to their appropriate type.
 * 
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class JndiConfigurationService {
    
	//***************************************************************
    // Public Interface
    //***************************************************************

	/**
	 * Creates a new instance of the JndiConfigurationService and initializes
	 * the initial context to the root context. 
	 * 
	 * @exception ConfigurationException thrown if there are any errors initializing
	 * the service.
	 */
	public JndiConfigurationService() throws ConfigurationException {
	
		initialize( null );
	}
	
	/**
	 * Creates a new instance of the JndiConfigurationService and initializes
	 * the initial context to the specified context.  All queries will
	 * be relative to this context.
	 * 
	 * @param context the initial context.
	 * @exception ConfigurationException thrown if there are any errors initializing
	 * the service.
	 */
	public JndiConfigurationService( String context ) throws ConfigurationException {

		initialize( context );
	}
	
    //***************************************************************
    // Public Interface
    //***************************************************************
    
    /**
     * Looks up the entryName parameter and returns it as a Object.
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Object value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    public Object getObject( String entryName ) throws ConfigurationException {
       
        return getProperty( entryName );
    }
    
    /**
     * Looks up the entryName parameter and returns it as a String.
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return String value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    public String getString( String entryName ) throws ConfigurationException {
        
        try {
            return (String) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            throw new ConfigurationException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Byte
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Byte value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    public Byte getByte( String entryName ) throws ConfigurationException {
        
        try {
            return (Byte) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            throw new ConfigurationException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Short
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Short value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    public Short getShort( String entryName ) throws ConfigurationException {
        
        try {
            return (Short) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            throw new ConfigurationException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Integer
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Integer value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    public Integer getInteger( String entryName ) throws ConfigurationException {
        
        try {
            return (Integer) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            throw new ConfigurationException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Long
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Long value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    public Long getLong( String entryName ) throws ConfigurationException {
        
        try {
            return (Long) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            throw new ConfigurationException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Boolean.
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Boolean value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    public Boolean getBoolean( String entryName ) throws ConfigurationException {
        
        try {
            return (Boolean) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            throw new ConfigurationException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Double
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Double value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    public Double getDouble( String entryName ) throws ConfigurationException {
        
        try {
            return (Double) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
            throw new ConfigurationException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * Looks up the entryName parameter and returns it as a Float
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Float value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    public Float getFloat( String entryName ) throws ConfigurationException {
        
        try {
            return (Float) getProperty( entryName );
        }
        catch( ClassCastException cce ) {
           throw new ConfigurationException( CLASS_CAST_ERROR + entryName, cce );
        }
    }
    
    /**
     * This method takes a context name, and returns all the Entry Names/Values
     * in a properties object.
     * 
     * @param context the initial context to load the properties from.  This method
     *                prepends the default context to this parameter, so the context
     *                parameter should start with the the portion after the default.
     * 
     * @return a Properties object with all the environment entries for the specified
     *         context.
     * 
     * @exception ConfigurationException occurs if there are any NamingExceptions thrown during
     *            the execution of this method.
     */
    public Properties buildContextProperties( String context ) throws ConfigurationException {
        try {
            
            //Retrieve a list of all entry names
            NamingEnumeration namingEnum = _envContext.list( context );
            
            NameClassPair nameClassPair;
            String entryName;
            Properties properties = new Properties();
            
            //Build properties object.
            while( namingEnum.hasMore() ) {
                
                nameClassPair = (NameClassPair) namingEnum.next();
                entryName = nameClassPair.getName();
                properties.put( entryName, String.valueOf( _envContext.lookup( context + "/" + entryName ) ) );
            }
            return properties;
        }
        catch( NamingException ne ) {
            throw new ConfigurationException( PROPERTIES_NAMING_ERROR + context, ne );
        }
    }
    
    //***************************************************************
    // Private Interface
    //***************************************************************

	/**
     * Retrieve the appropritate context to use to look up all environment
     * variables.
     * 
     * @param baseContext the context to use as the base for all lookups
     * 
     * @exception ConfigurationException thrown when there is a NamingException
     *            thrown when trying to lookup the appropriate context.
     */
    private void initialize( String baseContext ) throws ConfigurationException {
        
        try {
            InitialContext initialContext = new InitialContext();
			if( baseContext == null || baseContext.equals( "" ) ) {
				_envContext = initialContext;
			}
			else {
				_envContext = (Context) initialContext.lookup( baseContext );   	
			}
        }
        catch( NamingException ne ) {
            throw new ConfigurationException( INITIAL_NAMING_ERROR + baseContext, ne );
        }
    }
	
    /**
     * Looks up the property and returns it as an Object.  If any exceptions
     * are throw, they are caught, logged (as .debug() ), and a new 
     * ConfigurationException is thrown.
     * 
     * @param entryName the name of the configuration entry to lookup.
     * 
     * @return Object value of the configuration entry.
     * 
     * @exception ConfigurationException thrown if any errors occur performing this lookup.
     */
    private Object getProperty( String entryName ) throws ConfigurationException {
        
        if( _envContext == null ) {
            throw new ConfigurationException( "The Configuration Service has not been initialized.  Please call initialize( String baseContext)" );
        }
        
        try {
            return _envContext.lookup( entryName );
        }
        catch( NamingException ne ) {
            throw new ConfigurationException( NAMING_ERROR + entryName, ne );
        }
    }
    
    //***************************************************************
    // Variables

	private Context _envContext;

    //***************************************************************
    // Constants
    
    private static final String INITIAL_NAMING_ERROR = "Error retriving context: ";
    private static final String NAMING_ERROR = "Error retrieving configuration value for entry name: ";
    private static final String CLASS_CAST_ERROR = "Error casting value for entry name: ";
    private static final String PROPERTIES_NAMING_ERROR = "Naming error occured while building properties file for context: ";
}
//EOF