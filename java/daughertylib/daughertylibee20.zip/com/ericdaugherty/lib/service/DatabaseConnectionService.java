/******************************************************************************
 * $Workfile: DatabaseConnectionService.java $
 * $Revision: 4 $
 * $Author: Edaugherty $
 * $Date: 2/25/02 10:22p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are permitted provided 
 * that the following conditions are met:
 * 
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the 
 *   following disclaimer. 
 * 
 *   Redistributions in binary form must reproduce the 
 *   above copyright notice, this list of conditions and 
 *   the following disclaimer in the documentation and/or 
 *   other materials provided with the distribution. 
 * 
 *   Neither the name of Eric Daugherty nor the names of its 
 *   contributors may be used to endorse or promote products 
 *   derived from this software without specific prior written 
 *   permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.service;

//Java imports
import java.sql.*;
import javax.naming.*;
import javax.sql.DataSource;

//Log4j imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//DaughertyLib imports
import com.ericdaugherty.lib.error.SystemException;
import com.ericdaugherty.lib.error.DataStoreException;

/**
 * This class handles the management of all connections to Database resources.
 * <p>
 * This class can be used in two ways.  First, it can be used as a named singleton,
 * to provide cached access to a specific datasource.
 * <p>
 * Alternately, it can be used as an unamed singlton to provide access to a single
 * datasource.  This method is more useful in simple applicaitons that only access
 * a single datasource, or have a datasource that is used most of the time.
 * <p>
 * It is also possible to combine these two methods, so it can be used as both
 * an unnamed, and a named singleton at the same time.
 * <p> 
 * This class depends on the WebConfigurationService class to retrive the JNDI 
 * location of the datasource to use from the web.xml file.  To use this class,
 * the following code should be placed in your web.xml file:
 * 
 * <pre>
 * &lt;env-entry&gt;
 *   &lt;env-entry-name&gt;database datasource name&lt;/env-entry-name&gt;
 *   &lt;env-entry-value&gt;JNDI Name of the datasource&lt;/env-entry-value&gt;
 *   &lt;env-entry-type&gt;java.lang.String&lt;/env-entry-type&gt;
 * &lt;/env-entry&gt;
 * </pre>
 * 
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class DatabaseConnectionService {
    
    //***************************************************************
    // Constructor
    //***************************************************************

    private DatabaseConnectionService( String dataSourceName ) throws DataStoreException {

        //loadParameters();
    }
    
    //***************************************************************
    // Public Methods
    //***************************************************************

    /**
     * Retrieves a Database Connection and returns it.  The user of this 
     * method is responsible for calling .close() on this connection when
     * they are done.
     * 
     * @return Connection to the database.
     */
    public static Connection getDatabaseConnection() throws DataStoreException {
        
       DatabaseConnectionService instance = DatabaseConnectionService.getInstance();
       if( _instance._type.equals( "datasource" ) ) { 
           return null;// instance.getDataSource();
       }
       else {
           throw new DataStoreException( "Unsupported Source Type: " + _instance._type );
       }
    }
    
    /**
     * 
     */
    public static void initialize() throws DataStoreException {
        
        DatabaseConnectionService.getInstance();
    }
    
    //***************************************************************
    // Private Interface
    //***************************************************************

    private static DatabaseConnectionService getInstance() throws DataStoreException {
     
        if( _instance == null ) {
            synchronized( DatabaseConnectionService.class ) {
                if( _instance == null ) {
                    _instance = null;//new DatabaseConnectionService();
                }
            }
        }
        return _instance;
    }
    
    /**
     * Loads all the required parameters from the web.xml file
     */
    private static Log _log = LogFactory.getLog( DatabaseConnectionService.class );
    
    private static DatabaseConnectionService _instance = null;
    
    private String _type = "datasource";
    private String _dataSourceName;
}
//EOF