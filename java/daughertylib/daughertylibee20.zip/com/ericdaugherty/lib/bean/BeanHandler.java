/******************************************************************************
 * $Workfile: BeanHandler.java $
 * $Revision: 2 $
 * $Author: Edaugherty $
 * $Date: 5/09/02 3:04p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are permitted provided 
 * that the following conditions are met:
 * 
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the 
 *   following disclaimer. 
 * 
 *   Redistributions in binary form must reproduce the 
 *   above copyright notice, this list of conditions and 
 *   the following disclaimer in the documentation and/or 
 *   other materials provided with the distribution. 
 * 
 *   Neither the name of Eric Daugherty nor the names of its 
 *   contributors may be used to endorse or promote products 
 *   derived from this software without specific prior written 
 *   permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.bean;

//Java imports
import java.lang.reflect.*;
import java.util.HashMap;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//Local Imports
import com.ericdaugherty.lib.error.SystemException;

/**
 * Provides a Dynamic Proxy implementation for JavaBean interfaces.
 * 
 * Note: This implementation does NOT use a synchronized store.
 * <p>
 * Please refer to the <a href="package-summary.html#package_description">
 * package level documentation</a> for further information.
 * 
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class BeanHandler implements InvocationHandler { 
    
	//***************************************************************
    // Public Interface
    //***************************************************************

	/**
	 * DynamicProxy Invoke Method.  Entry point for all Dynamic Proxy
	 * Calls.
	 * 
	 * @param proxy 
	 * @param method The method that was invoked.
	 * @param args The arguments passed in to the method.
	 */
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
     
		String methodName = method.getName();
		
		if( methodName.startsWith( "get" ) ) {
			return _values.get( methodName.substring( 3 ) );
		}
		else if( methodName.startsWith( "is" ) ) {
			return _values.get( methodName.substring( 2 ) );
		}
		else if( methodName.startsWith( "set" ) ) {
			_values.put( methodName.substring( 3 ), args[0] );
			return null;
		}
		
		throw new SystemException( "Method Unsupported" );
    }

	//***************************************************************
    // Variables

	private HashMap _values = new HashMap();

    /** Logger for this class.  */
    private static Log _log = LogFactory.getLog( BeanHandler.class );
}
