/******************************************************************************
 * $Workfile: CascadingException.java $
 * $Revision: 5 $
 * $Author: Edaugherty $
 * $Date: 5/21/02 1:19p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are permitted provided 
 * that the following conditions are met:
 * 
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the 
 *   following disclaimer. 
 * 
 *   Redistributions in binary form must reproduce the 
 *   above copyright notice, this list of conditions and 
 *   the following disclaimer in the documentation and/or 
 *   other materials provided with the distribution. 
 * 
 *   Neither the name of Eric Daugherty nor the names of its 
 *   contributors may be used to endorse or promote products 
 *   derived from this software without specific prior written 
 *   permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.error;

//Java imports
import java.io.*;
import java.text.MessageFormat;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Provides the base functionality for all Exception classes defined in the error 
 * package.  This class is abstract and should not be used directly.  Instead, please
 * use either <a href="BusinessException.html">BusinessException</a>, 
 * <a href="SystemException.html">SystemException</a>, or one of the classes 
 * that extend those exceptions.
 * <p>
 * This class provides two major functions, the ability to cascade exceptions, and
 * the ability to easily format and print exceptions.
 * CascadingException exposes several constructors that can be overloaded in subclasses.
 * These constructors take a variety of parameters, but one important parameter is 
 * <a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Exception.html">
 * <code>java.lang.Exception</code></a>.  If an exception is passed to this constructor
 * it is captured as a private variable.  When the printStackTrace() method is called,
 * CascadingException not only prints its own stack trace, but also prints out the
 * stack trace of the captured exception.  This behavior is recursive, and 
 * there is no limit on the length of the 'cascade'.  However, it is not recommended
 * to cascade more than 2 levels deep.  Additionally, the getStackTrace() 
 * method has been added to return the stack trace as a string.
 * <p>
 * This class also provides 'advanced' message formatting.
 * <p>
 * <b>MessageFormat</b><br>
 * Error messages can be formatted using the 
 * <a href="http://java.sun.com/j2se/1.3/docs/api/java/text/MessageFormat.html">MessageFormat</a> 
 * class.  The constructors have been overloaded to accept an array of Objects.  If
 * this parameter is set, the message will be parsed using the MessageFormat class, 
 * and the specified Object array. 
 * <p>
 * This exception is currently written using JDK 1.3.1.  JDK 1.4 provides some of the same
 * functionality provided here.  When JDK 1.4 becomes widely accepted, this class will be modified to
 * utilize the new functionality provided by JDK 1.4.  However, the changes should only effect the
 * implementation of this class, and not its interface.  This class will continue to provide functionality
 * not provided in the 1.4 exception class, and will continue to be the base class for all Exceptions in this package.
 * <p>
 * For more information about the error package, please refer to the <a href="package-summary.html">
 * package level documentation</a>.
 * 
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public abstract class CascadingException extends Exception implements Serializable { 
    
    //***************************************************************
    // Constructors
    //***************************************************************

	/**
	 * Creates a new exception without any additional information.
	 */
    public CascadingException() {
		super();
    }
    
	/**
	 * Creates a new exception and nests the exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>)
	 * passed in as a parameter.
	 * 
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */
    public CascadingException( Throwable nextedException ) {
		super();
		_nestedException = nextedException;
    }
    
	/**
	 * Creates a new exception using the provided message.  No original 
	 * Exception is captured.
	 * 
	 * @param msg A message describing the error that occured.
	 */
    public CascadingException( String msg ) {
        super(msg);
    }
	
	/**
	 * Creates a new exception using the provided message.  No original 
	 * Exception is captured.
	 * <p>
	 * Also accepts an Object array for use in formatting the message using the
	 * <a href="http://java.sun.com/j2se/1.3/docs/api/java/text/MessageFormat.html">MessageFormat</a> 
	 * class.
	 * 
	 * @param msg A message describing the error that occured.
	 * @param messageObjects objects used to format the msg String.
	 */
    public CascadingException( String msg, Object[] messageObjects ) {
        super(msg);
		_formatObjects = messageObjects;
    }
    
	/**
	 * Creates a new exception using the provides message and exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>).
	 * @param msg A message describing the error that occured.
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */
    public CascadingException( String msg, Throwable nestedException ) {
        this(msg);
        _nestedException = nestedException;
    }
	
	/**
	 * Creates a new exception using the provides message and exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>).
	 * <p>
	 * Also accepts an Object array for use in formatting the message using the
	 * <a href="http://java.sun.com/j2se/1.3/docs/api/java/text/MessageFormat.html">MessageFormat</a> 
	 * class.
	 * 
	 * @param msg A message describing the error that occured.
	 * @param messageObjects objects used to format the msg String.
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */
    public CascadingException( String msg, Object[] messageObjects, Throwable nestedException ) {
        this(msg);
		_formatObjects = messageObjects;
        _nestedException = nestedException;
    }

	//***************************************************************
    // Public Interface
    //***************************************************************

	/**
	 * Provides access to the nested exception stored in this Exception.
	 * 
	 * @return the nestedException that was passeed to this class in the
	 * constructor, or null if none exists.
	 */
    public Throwable getNestedException() {
		return _nestedException;
	}
	
	/**
	 * Iderates through all the nested CascadingExceptions to genrate the
	 * entire stack trace for the entire tree.
	 * <p>
	 * The resulting stack trace will contain the stack trace from the
	 * 'deepest' exception first.  The last stack trace displayed will 
	 * be the stack trace for this exception.
	 * 
	 * @return String containing the stack trace of the entire cascade of exceptions.
	 */
    public String getStackTraceString() {

		StringBuffer traceBuffer = new StringBuffer();
		
		if( _nestedException != null ) {
        
			// descend through linked-list of nesting exceptions, & output trace
			// note that this displays the 'deepest' trace first
			if (_nestedException instanceof CascadingException) {
			    
				traceBuffer.append ( ((CascadingException)_nestedException).getStackTraceString() );
			}
			else {
				traceBuffer.append ( generateStackTraceString( _nestedException ) );
			}
			
			traceBuffer.append("-------- nested by:\n");
		}

		traceBuffer.append( generateStackTraceString() );
        return traceBuffer.toString();
    }

	//***************************************************************
    // java.leng.Exception methods
	//***************************************************************
	
    /**
     * Overrides the Exception.getMessage() method to include the Exception message
     * information from the nested exception.
     * 
     * @return the Exception message from this exception and the nested
     * exception.
     */
    public String getMessage() {
		
		//The String to build.
		StringBuffer retVal = new StringBuffer();
		
        //Add the String Message
        String superMessage = super.getMessage();

		if( superMessage != null && superMessage.length() > 0 ) {
			
			if( _formatObjects == null || _formatObjects.length == 0 ) {
				retVal.append( superMessage );
			}
			else {
				retVal.append( MessageFormat.format( superMessage, _formatObjects ) );
			}
		}
		
        //Add the Nested Exception's Message
		Throwable nestedException = getNestedException();
		
		if ( nestedException != null ){
			
			//Get the string and check.  If OK, add...
			String nestedString = nestedException.toString();
			
			if( nestedString != null && nestedString.length() > 0 ) {
   
				if ( retVal.length() > 0 ) {
					retVal.append("\r\nNestedException: ");
				}
				retVal.append( nestedString );
			}
		}
		
        return retVal.toString();
    }

    /**
     * Overrides the Exception.toString() method to include the nested exception's 
     * toString output.
     * 
     * @return the toString message from this exception and the nested
     * exception.
     */
    public String toString() {
		
		StringBuffer retVal = new StringBuffer(super.toString());

		/*
        if (getNestedException() != null)
            retVal.append("; \n\t---> nested ").append(getNestedException());
		*/
        return retVal.toString();
    }

	/**
	 * Overrides the Exception.printStackTrace() method to print the
	 * entire stack trace for this exception 
     * and the entire cascade of exceptions.
	 */
    public void printStackTrace() {
        System.out.println( getStackTraceString() );
    }
    
	/**
	 * Overrides the Exception.printStackTrace() method to print
	 * the entire stack trace for this exception 
     * and the entire cascade of exceptions to the specified
     * PrintWriter.
     * 
     * @param printWriter - the PrintWriter to write the stack trace to.
	 */
    public void printStackTrace(PrintWriter printWriter) {
        printWriter.print( getStackTraceString() );
    }
    
	/**
	 * Overrides the Exception.printStackTrace() method to print
	 * the entire stack trace for this exception 
     * and the entire cascade of exceptions to the specified
     * PrintWriter.
     * 
     * @param printWriter - the PrintStream to write the stack trace to.
	 */
    public void printStackTrace(PrintStream printStream) {
        printStream.print( getStackTraceString() );
    }
  
	//***************************************************************
    // Private Interface
    //***************************************************************

	private String generateStackTraceString() {
        StringWriter stringWriter = new StringWriter();
        super.printStackTrace( new PrintWriter(stringWriter) );
        return stringWriter.toString();
	}
	
	/**
	 * Generates the stack trace for the given Throwable and returns
	 * it as a string.
	 * 
	 * @param throwable the exception to get the stack trace from.
	 */
    private String generateStackTraceString( Throwable throwable ) {
        StringWriter stringWriter = new StringWriter();
        throwable.printStackTrace( new PrintWriter(stringWriter) );
        return stringWriter.toString();
    }
	//***************************************************************
    // Private Variables
	//***************************************************************

	/** Log4j Category instance */
	private static Log _log = LogFactory.getLog( CascadingException.class );
	
	/** The nested exception. */
    private Throwable _nestedException;
	
	/** Objects to be used with the MessageFormat class */
	private Object[] _formatObjects;
	
	/** 
	 * Caches version of the formatted message so the MessageFormat 
	 * class does not get called multiple times.
	 */
	private String _formattedMessage;
}
//EOF
