/******************************************************************************
 * $Workfile: SystemException.java $
 * $Revision: 4 $
 * $Author: Edaugherty $
 * $Date: 5/09/02 3:05p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are permitted provided 
 * that the following conditions are met:
 * 
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the 
 *   following disclaimer. 
 * 
 *   Redistributions in binary form must reproduce the 
 *   above copyright notice, this list of conditions and 
 *   the following disclaimer in the documentation and/or 
 *   other materials provided with the distribution. 
 * 
 *   Neither the name of Eric Daugherty nor the names of its 
 *   contributors may be used to endorse or promote products 
 *   derived from this software without specific prior written 
 *   permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.error;

//Java imports
import java.io.Serializable;

/**
 * Indicates that a serious error has occured and could not be recoved.  
 * This exception (and its subclasses) should be used to indicate errors 
 * that occured interacting with external systems, or when the application
 * is in a state that should never occur.
 * <p>
 * For example, DatabaseException extends this class to encapsulate all 
 * errors that occur interacting with external data stores.
 * <p>
 * Another example is a case where a parameter passed to a method 
 * is null when this is an 'impossible' condition (the method requires the 
 * parameter, and the calling method has broken the contract).  
 * <p>
 * Note, this class should NOT be used to indicate errors in user input, or 
 * other conditions where the user has input information that is invalid.  These
 * types of errors should be handled with the <a href="BusinessException.html">BusinessException</a>
 * class.
 * 
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class SystemException extends CascadingException implements Serializable { 
    
	/**
	 * Creates a new exception without any additional information.
	 */
    public SystemException() {
        super();
    }
    
	/**
	 * Creates a new exception and nests the exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>)
	 * passed in as a parameter.
	 * 
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */	
    public SystemException( Throwable nextedException ) {
        super( nextedException );
    }
    
	/**
	 * Creates a new exception using the provided message.  No original 
	 * Exception is captured.
	 * 
	 * @param msg A message describing the error that occured.
	 */
    public SystemException( String msg ) {
        super( msg );
    }
    
	/**
	 * Creates a new exception using the provided message.  No original 
	 * Exception is captured.
	 * <p>
	 * Also accepts an Object array for use in formatting the message using the
	 * <a href="http://java.sun.com/j2se/1.3/docs/api/java/text/MessageFormat.html">MessageFormat</a> 
	 * class.
	 * 
	 * @param msg A message describing the error that occured.
	 * @param messageObjects objects used to format the msg String.
	 */
    public SystemException( String msg, Object[] messageObjects ) {
        super(msg, messageObjects);
    }
	
	/**
	 * Creates a new exception using the provides message and exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>).
	 * @param msg A message describing the error that occured.
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */
	public SystemException( String msg, Throwable nestedException ) {
        super( msg, nestedException );
    }
	
	/**
	 * Creates a new exception using the provides message and exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>).
	 * <p>
	 * Also accepts an Object array for use in formatting the message using the
	 * <a href="http://java.sun.com/j2se/1.3/docs/api/java/text/MessageFormat.html">MessageFormat</a> 
	 * class.
	 * 
	 * @param msg A message describing the error that occured.
	 * @param messageObjects objects used to format the msg String.
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */
    public SystemException( String msg, Object[] messageObjects, Throwable nestedException ) {
		super( msg, messageObjects, nestedException );
	}
}

