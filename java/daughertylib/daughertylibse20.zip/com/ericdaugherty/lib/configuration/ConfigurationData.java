/******************************************************************************
 * $Workfile: ConfigurationData.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 5/09/02 2:51p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration;

//Java imports
import java.util.*;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Container for configuration data from a single
 * <a href="ConfigurationSource.html">ConfigurationSource</a>.
 *
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class ConfigurationData {

    //***************************************************************
    // Public Methods
	//***************************************************************

    /**
     * Default constructor.  If this constructor is used, the
     * <a href="ConfigurationSource.html">ConfigurationSource</a> must
     * call setKeys( java.util.Collection ) and setValues( java.util.Collection )
     * before returning this instance to the
     * <a href="ConfigurationService.html">ConfigurationService</a>.
     */
    public ConfigurationData() {
    }

    /**
     * Initializes this instance with the provided keys and values.
     * The Collection implementations should maintain the order of
     * the data because order is important.
     *
     * @param keys a Collection of configuration keys.
     * @param values a Collection of configuration values.
     */
    public ConfigurationData( Collection keys, Collection values ) {
        _keys = keys;
        _values = values;
    }

    //***************************************************************
    // Public Methods
	//***************************************************************

    /**
     * Returns an Iterator containing the all the keys (in order).  If
     * no keys are defined, and empty Iterator is returned.
     * <p>
     * This method never returns null.
     */
    public Iterator getKeys() {

        if( _keys != null ) {
            return _keys.iterator();
        }
        else {
            //Return an empty iterator if the _keys has not been set.
            return new HashMap().values().iterator();
        }
    }

    /**
     * Returns an Iterator containing the all the values (in order).  If
     * no values are defined, and empty Iterator is returned.
     * <p>
     * This method never returns null.
     */
    public Iterator getValues() {

        if( _values != null ) {
            return _values.iterator();
        }
        else {
            //Return an empty iterator if the _values has not been set.
            return new HashMap().values().iterator();
        }
    }

    /**
     * Sets the configuration keys collection to the provided value.
     * The Collection implementations should maintain the order of
     * the data because order is important.
     *
     * @param keys a Collection of configuration keys.
     */
    public void setKeys( Collection keys ) {
        _keys = keys;
    }

    /**
     * Sets the configuration values collection to the provided value.
     * The Collection implementations should maintain the order of
     * the data because order is important.
     * <p>
     * Note: This method should not be called after this instance has
     * been provided to the <a href="ConfigurationService.html">ConfigurationService</a>.
     *
     * @param keys a Collection of configuration values.
     */
    public void setValues( Collection values ) {
        _values = values;
    }

    //***************************************************************
    // Variables
	//***************************************************************

    private Collection _keys = null;
    private Collection _values = null;

    /** Logger instance */
	private static Log _log = LogFactory.getLog( ConfigurationData.class );
}

//EOF
