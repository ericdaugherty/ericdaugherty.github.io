/******************************************************************************
 * $Workfile: ConfigurationServiceTest.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 5/09/02 2:51p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration.test;

//Java imports
import java.util.Properties;

//jUnit imports
import junit.framework.*;

//Local imports
import com.ericdaugherty.lib.configuration.*;
import com.ericdaugherty.lib.error.*;

/**
 * Test Class for <a href="../ConfigurationService.html">ConfigurationService</a>
 */
public class ConfigurationServiceTest extends ConfigurationTestBase
{	
	public ConfigurationServiceTest( String name ) {
		super( name );
	}
	
	//Setup and teardown inherited from base class
	
	//***************************************************************
    // Test Cases
    //***************************************************************

    /**
     * Test parseFirstNode method.
     */
	public void testParseFirstNode() {
		assertEquals( ConfigurationService.getInstance().parseFirstNode( KEY_1 ), KEY_1_FIRST_NODE );
		assertEquals( ConfigurationService.getInstance().parseFirstNode( KEY_2 ), KEY_2 );
	}

    /**
     * Test parseFirstNodes method.
     */
	public void testParseFirstNodes() {
		assertEquals( ConfigurationService.getInstance().parseFirstNodes( KEY_1 ), KEY_1_FIRST_NODES );
		assertEquals( ConfigurationService.getInstance().parseFirstNodes( KEY_2 ), "" );
	}

    /**
     * Test parseLastNode method.
     */
	public void testParseLastNode() {
		assertEquals( ConfigurationService.getInstance().parseLastNode( KEY_1 ), KEY_1_LAST_NODE );
		assertEquals( ConfigurationService.getInstance().parseLastNode( KEY_2 ), KEY_2 );
	}

    /**
     * Test parseLastNodes method.
     */
	public void testParseLastNodes() {
		assertEquals( ConfigurationService.getInstance().parseLastNodes( KEY_1 ), KEY_1_LAST_NODES );
		assertEquals( ConfigurationService.getInstance().parseLastNodes( KEY_2 ), "" );
	}

    /**
     * Test <a href="../ConfigurationService.html#convertDelimiter(java.lang.String, java.lang.String)">
     * convertDelimiter( String sourceKey, String sourceDelimiter )</a> method.
     */
    public void testConvertDelimiter() {

        ConfigurationService service = ConfigurationService.getInstance();

        assertEquals( "my.newly.delimited.string", service.convertDelimiter( "my*newly*delimited*string", "*" ) );
        assertEquals( "my.newly.delimited.string", service.convertDelimiter( "my|newly|delimited|string", "|" ) );
        assertEquals( "simple", service.convertDelimiter( "simple", "|" ) );
    }

	/**
	 * Performs tests on the GetValue method to verify that the parameters can
	 * be accesses successfully.
	 */
	public void testGetValue() {
		try {

			ConfigurationService service = ConfigurationService.getInstance();
			String delimiter = service.getDelimiter();

			assertEquals( "rootvalue1", service.getValue( "root1" ) );
            assertEquals( "rootvalue1caps", service.getValue( "rOOt1" ) );
			assertEquals( "rootvalue2", service.getValue( "root2" ) );
            assertEquals( "rootvalue2caps", service.getValue( "Root2" ) );
            assertEquals( "rootvalue3", service.getValue( "root3" ) );

            assertEquals( service.getValue( "nodelevel1" + delimiter + "nodelevel2" + delimiter + "nodelevel3" + delimiter + "root1" ), "rootvalue11" );
			assertEquals( service.getValue( "nodelevel1" + delimiter + "nodelevel2" + delimiter + "nodelevel3" + delimiter + "root2" ), "rootvalue22" );
			assertEquals( "rootvalue33", service.getValue( "nodelevel1" + delimiter + "nodelevel2" + delimiter + "nodelevel3" + delimiter + "root3" ) );
		}
		catch( NotFoundException nfe ) {
			assertTrue( "NotFoundException Occured: " + nfe.getMessage(), false );
		}
	}
	
	/**
	 * Performs tests on the GetValues method to verify that the parameters can
	 * be accesses successfully.
	 */
	public void testGetValues() {
		try {

			ConfigurationService service = ConfigurationService.getInstance();
			String delimiter = service.getDelimiter();
			Properties props = service.getValues( );

            assertEquals( "rootvalue1", props.getProperty( "root1" ) );
            assertEquals( "rootvalue1caps", props.getProperty( "rOOt1" ) );
			assertEquals( "rootvalue2", props.getProperty( "root2" ) );
            assertEquals( "rootvalue2caps", props.getProperty( "Root2" ) );
            assertEquals( "rootvalue3", props.getProperty( "root3" ) );

            props =  service.getValues( "nodelevel1" + delimiter + "nodelevel2" + delimiter + "nodelevel3" );

            assertEquals( "rootvalue11", props.getProperty ( "root1" ) );
			assertEquals( "rootvalue22", props.getProperty ( "root2" ) );
			assertEquals( "rootvalue33", props.getProperty ( "root3" ) );
		}
		catch( NotFoundException nfe ) {
			assertTrue( "NotFoundException Occured: " + nfe.getMessage(), false );
		}
	}

    /**
     * Test <a href="../ConfigurationService.html#getAllValues()">getAllValues()</a> and
     * <a href="../ConfigurationService.html#getAllValues(java.lang.String)">getAllValues( String key )</a>
     * methods.
     */
    public void testGetAllValues() {
        try {
            ConfigurationService service = ConfigurationService.getInstance();
            String delimiter = service.getDelimiter();
            String node2 = "nodelevel1" + delimiter + "nodelevel2";
            String node3 = "nodelevel1" + delimiter + "nodelevel2" + delimiter + "nodelevel3";

            //Get ALL the values in the tree.
            Properties props = service.getAllValues();

            //Check the root values.
            assertEquals( "rootvalue1", props.getProperty( "root1" ) );
            assertEquals( "rootvalue3", props.getProperty( "root3" ) );

            //Check down the tree.
            assertEquals( "rootvalue11", props.getProperty ( node3 + delimiter + "root1" ) );
			assertEquals( "rootvalue22", props.getProperty ( node3 + delimiter + "root2" ) );
			assertEquals( "rootvalue33", props.getProperty ( node3 + delimiter + "root3" ) );

            //Get All values relative to Node2.
            props = service.getAllValues( node2 );

            assertEquals( "rootvalue11", props.getProperty ( "nodelevel3" + delimiter + "root1" ) );
			assertEquals( "rootvalue22", props.getProperty ( "nodelevel3" + delimiter + "root2" ) );
			assertEquals( "rootvalue33", props.getProperty ( "nodelevel3" + delimiter + "root3" ) );

            //Get All values relative to Node2.
            props = service.getAllValues( node3 );

            assertEquals( "rootvalue11", props.getProperty ( "root1" ) );
			assertEquals( "rootvalue22", props.getProperty ( "root2" ) );
			assertEquals( "rootvalue33", props.getProperty ( "root3" ) );

        }
		catch( NotFoundException nfe ) {
			assertTrue( "NotFoundException Occured: " + nfe.getMessage(), false );
		}
    }

    /**
     * Tests to verify ConfigurationService handles Environment Keywords correctly.
     */
    public void testEnvironmentKeywords() {
        try {

            ConfigurationService service = ConfigurationService.getInstance();
            String delimiter = ConfigurationService.getInstance().getDelimiter();

            assertEquals( "rootvalues1", service.getValue( "envroot1" ) );
            assertEquals( "rootvalues2", service.getValue( "envroot2" ) );
            assertEquals( "rootvalues3", service.getValue( "envroot3" ) );

            assertEquals( "rootvalues4", service.getValue( "envroot4" ) );

            String node3 = "nodelevel1" + delimiter + "nodelevel2" + delimiter + "nodelevel3";

            assertEquals( "rootvalues11", service.getValue( node3 + delimiter + "envroot1" ) );
            assertEquals( "rootvalues44", service.getValue( node3 + delimiter + "envroot4" ) );
        }
        catch( NotFoundException nfe ) {
            assertTrue( "NotFoundException Occured: " + nfe.getMessage(), false );
		}
    }

    /**
     * Test <a href="../ConfigurationService.html#refresh()">refresh()</a> method.
     * <p>
	 * Performs a refresh and tests to verify that the value of a parameter
	 * was updated.
	 */
	public void testRefresh() {
        try {

            ConfigurationService service = ConfigurationService.getInstance();
            String delimiter = service.getDelimiter();

            //Change the values so they will be different after refresh() is called.
            _testSource.setValue( "root1", "rootvalue3" );

            service.refresh();

			assertEquals( "rootvalue3", service.getValue( "root1" ) );
		}
		catch( NotFoundException nfe ) {
			assertTrue( "NotFoundException Occured: " + nfe.getMessage(), false );
		}
        catch( ConfigurationException ce ) {
            assertTrue( "Configuration Exception Occured while trying to refresh ConfigurationService: " + ce.getMessage(), false );
        }
	}

    /**
	 * Tests a ConfigurationSource initialized update.
	 */
	public void testUpdateConfigurationSource() {
        try {

            ConfigurationService service = ConfigurationService.getInstance();
            String delimiter = service.getDelimiter();

            //Change the values so they will be different after updateConfigurationSource
            //is called.
            _testSource.setValue( "root1", "rootvalue4" );
            _testSource.removeValue( "Root2" );
            _testSource2.setValue( "root3", "rootvalue4" );

            //Thread.sleep( 2000 );
            service.updateConfigurationSource( _testSource );

            //This value should change since we called updateConfigurationSource on
            //it's source.
            assertEquals( "TestSource1 was not updated", "rootvalue4", service.getValue( "root1" ) );
            //This one should not be changed yet.
            assertEquals( "TestSource2 was updated too soon", "rootvalue3", service.getValue( "root3" ) );

            service.updateConfigurationSource( _testSource2 );

            //This one should now be changed.
            assertEquals( "TestSource 2 was not updated.", "rootvalue4", service.getValue( "root3" ) );

            try {
                service.getValue( "Root2" );
                assertTrue( "Old value Root2 was not removed.", false );
            }
            catch( NotFoundException nfe ) {
                //This is the success case.
            }

		}
		catch( NotFoundException nfe ) {
			assertTrue( "NotFoundException Occured: " + nfe.getMessage(), false );
		}
        catch( Throwable ce ) {
            assertTrue( "Configuration Exception Occured while trying to refresh ConfigurationService: " + ce.getMessage(), false );
        }

        //Cleanup after ourselves for the next test.
        setUp();
	}

	/**
	 * Verifies that the getConfigurationSource array actually returns the
	 * same instance of the configuration source the we used to create it.
	 */
	public void testGetConfigurationSources() {

		ConfigurationService service = ConfigurationService.getInstance();
		assertTrue( _testSource == service.getConfigurationSources()[0] );
	}

	/**
	 * Tests the initialize(String delimiter) method to verify that the delimiter
	 * is in fact changed, and that the old singleton instance is thrown out.
	 * <p>
	 * This method also tests multi-charecter delimiters.
	 */
    public void testInitialize() {
        try {

            String newDelimiter = "xxx";

            ConfigurationService service = ConfigurationService.getInstance();

            service.initialize( newDelimiter );

            MemorySource newMapConfigSource = new MemorySource();
            newMapConfigSource.setValue( "a" + newDelimiter + "b" + newDelimiter + "c" + newDelimiter + "aa" , "1" );

            service.addConfigurationSource( newMapConfigSource );

            assertEquals( "1", service.getValue( "a" + newDelimiter + "b" + newDelimiter + "c" + newDelimiter + "aa" ) );
		}
		catch( NotFoundException nfe ) {
			assertTrue( "NotFoundException Occured: " + nfe.getMessage(), false );
		}
        catch( ConfigurationException ce ) {
            assertTrue( "Configuration Exception Occured while trying to refresh ConfigurationService: " + ce.getMessage(), false );
        }
	}

    /**
     * Test <a href="../ConfigurationService.html#removeConfigurationSource(com.ericdaugherty.lib.configuration.ConfigurationSource)">
     * removeConfigurationSource( ConfigurationSource source )</a> method.
     * <p>
     * Verifies that Configuraiton Sources are actually removed.
     */
    public void testRemoveConfigurationSource() {

        ConfigurationService service = null;

        try {

            service = ConfigurationService.getInstance();

            //First, verify that testsource2 is added and has the right value.
            assertEquals( "TestSource2 Value incorrect.", "rootvalue3", service.getValue( "root3" ) );

            service.removeConfigurationSource( _testSource2 );

        }
        catch( NotFoundException nfe ) {
			assertTrue( "NotFoundException Occured: " + nfe.getMessage(), false );
		}

        //The value should now be removed.
        try {
            //Should throw NotFoundException.
            service.getValue( "root3" );
            assertTrue( "Value was not removed.", false );
        }
        catch (NotFoundException nfe ) {
            //This should happen.
            assertTrue( "Value was removed correctly", true );
        }
    }

    public void testNamedSingleton() {
        try {
            ConfigurationService defaultInstance = ConfigurationService.getInstance();
            defaultInstance.initialize( ".x." );
            ConfigurationService named1Instance = ConfigurationService.getInstance( "named1" );
            named1Instance.initialize( ".y." );
            ConfigurationService named2Instance = ConfigurationService.getInstance( "named2" );
            named2Instance.initialize( ".z." );

            MemorySource source1 = new MemorySource();
            MemorySource source2 = new MemorySource();
            MemorySource source3 = new MemorySource();

            source1.addValue( "root1", "sourceValue1");
            source1.addValue( "node1.x.root1", "nodeValue1" );

            source2.addValue( "root2", "sourceValue2");
            source2.addValue( "node2.y.root2", "nodeValue2" );

            source3.addValue( "root3", "sourceValue3");
            source3.addValue( "node3.z.root3", "nodeValue3" );

            defaultInstance.addConfigurationSource( source1 );
            named1Instance.addConfigurationSource( source2 );
            named2Instance.addConfigurationSource( source3 );


            assertEquals( "sourceValue1", defaultInstance.getValue( "root1" ));
            assertEquals( "nodeValue1", defaultInstance.getValues( "node1" ).getProperty( "root1" ));
            assertEquals( "sourceValue2", named1Instance.getValue( "root2" ));
            assertEquals( "nodeValue2", named1Instance.getValues( "node2" ).getProperty( "root2" ));
            assertEquals( "sourceValue3", named2Instance.getValue( "root3" ));
            assertEquals( "nodeValue3", named2Instance.getValues( "node3" ).getProperty( "root3" ));
        }
        catch( NotFoundException nfe ) {
            assertTrue( "NotFoundException Occured: " + nfe.getMessage(), false );
        }
        catch( ConfigurationException ce ) {
            assertTrue( "Configuration Exception Occured while trying to refresh ConfigurationService: " + ce.getMessage(), false );
        }
    }

	//***************************************************************
    // Variables
    //***************************************************************

}
//EOF