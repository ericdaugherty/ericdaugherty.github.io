/******************************************************************************
 * $Workfile: MemorySource.java $
 * $Revision: 1 $
 * $Author: Edaugherty $
 * $Date: 5/09/02 2:51p $
 *
 ******************************************************************************
 * Copyright (c) 2001-2002, Eric Daugherty
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   Redistributions of source code must retain the above
 *   copyright notice, this list of conditions and the
 *   following disclaimer.
 *
 *   Redistributions in binary form must reproduce the
 *   above copyright notice, this list of conditions and
 *   the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 *   Neither the name of Eric Daugherty nor the names of its
 *   contributors may be used to endorse or promote products
 *   derived from this software without specific prior written
 *   permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.ericdaugherty.lib.configuration;

//Java imports
import java.util.*;

//Apache Imports
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//Local imports
import com.ericdaugherty.lib.error.NotFoundException;

/**
 * Provides a simple implementation of the ConfigurationSource interface.
 * <p>
 * This implementation provides a simple 'in memory' configuration source.
 * This source does not read any information from external sources, but
 * relies on other classes to 'set' configuarion values using the provided
 * methods.
 * <p>
 * This Source is not generally useful for Production systems, but may be useful
 * during early Development.  It is also useful to 'test' the framework, and to 
 * gain a general understanding of how it work.
 * <p>
 * This implementation may also be useful as a base class for other 
 * ConfigurationSource implementations.
 * 
 * @author <a href="mailto:java@ericdaugherty.com">Eric Daugherty</a> (<a href="http://www.ericdaugherty.com/java/daughertylib">http://www.ericdaugherty.com/java/daughertylib</a>)
 */
public class MemorySource implements ConfigurationSource
{

    /**
     * This implementation has no configurable parameters, so this
     * method is not implemented.
     */
    public void initialize( ConfigurationService service, Properties properties) {
    }

    /**
	 * Provides access to the configuration parameters.
     *
     * @return ConfigurationData contains collections of the configuration keys and values.
	 */
    public ConfigurationData getConfigurationData() {
        return new ConfigurationData( _keys, _values );
    }

	/**
	 * Accessor method for configuration values.
	 *
	 * @param node the first part of the full parameter key.
	 * @param name the name of the parameter.  The last part of the full parameter key.
	 * @param value the actual value of the parameter.
	 */
    public String getValue( String key ) throws NotFoundException {

        int index = _keys.indexOf( key );

        if( index >= 0 ) {
            return (String) _values.get( index );
        }
        else {
            throw new NotFoundException( "The key: " + key + " could not be found in MemorySource." );
        }
    }

	/**
	 * Convenient method to add new parameters.  This method will
	 * add the specified key/value pair.
	 * <p>
     * If the key already exists, it will be overwritten with the new value.
     * This behaviour is is slightly different than the standard 'first definition
     * wins', but has been implemented this way to facilitate testing.
     * If multiple keys are defined, only the first one in the list
     * is modified.
     * <p>
     * The addValue method allows multiple key definitions.
     *
	 * @param key the full parameter key.
	 * @param value the actual value of the parameter.
	 */
	public void setValue( String key, String value ) {
        if( _keys.contains( key ) ) {
            _values.set( _keys.indexOf( key ), value );
        }
        else {
            addValue( key, value );
        }
	}

    /**
     * Adds a new key regardless of whether the key exists or not.
     * This is useful for testing the behaviour of the ConfigurationService
     * add order priority.
     *
     * @param key the full parameter key.
	 * @param value the actual value of the parameter.
     */
    public void addValue( String key, String value ) {
        _keys.add( key );
        _values.add( value );
    }

    /**
     * Removes the specified key and associated value.
     */
    public void removeValue( String key ) {
        int index =  _keys.indexOf( key );
        if( index >= 0 ) {
            _keys.remove( index );
            _values.remove( index );
        }
    }

    //***************************************************************
    // Variables
    //***************************************************************

    private ArrayList _keys = new ArrayList();
    private ArrayList _values = new ArrayList();

    /** Logger instance */
	private static Log _log = LogFactory.getLog( MemorySource.class );
}
