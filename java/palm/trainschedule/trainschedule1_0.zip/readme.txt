TrainSchedule

Written by Eric Daugherty
trainschedule@email.com
http://www.ericdaugherty.com/java/palm/trainschedule

Version 1.0
Released 2/2/2001

Java Train Schedule is a simple Java application written for the Palm OS platform.  It 
allows the users an easy way to view commuter train schedules.  Although this application 
was written for the Chicago Metra train system, there is no reason that data from other 
systems could not be loaded for this application.

Java Train Schedule is completely free.  I wrote it as an introduction the Sun 
Microsystems' J2ME CLDC SDK, and the kAWT toolkit.��

There are two separate versions of the TrainSchedule application.  The initial version was 
written using the kAWT toolkit.  Once I completed this, I ported the GUI to use the
KVM GUI classes (kJava).  While the kAWT version has much more sophisticated GUI, the 
kJava version performs much better.  Both versions are included in the binary 
distribution.

In order to successfully port the application to the kJava classes, I found the ListBox 
widget written by Stepane Schmitz invaluable.  You can find more information about this 
at his website.

If you are interested in Java development for the Palm and would like to see the source 
code for this application, you can email me at trainschedule@email.com

Due to the constraints of the Java KVM, the limited power of the Palm hardware, and my 
limited interest, the performance of the TrainSchedule application is extremely slow.  
I would only recommend this application for the fastest Palm hardware, and the very 
patient!  I have found that the kJava version is much more useable from a performance 
standpoint.�

History:

1.0 Final () - Initial Full Release
- Replaced usage of the 3rd Party Date class with java.util.Calendar
- Fixed Bug: Duration is incorrect for trains that leave before midnight but arrive 
  the next day. 
- Fixed Bug: Searches with a time of 12 AM are interpreted as Noon.
- Added kJava version to distribution.

1.0 Beta (1/29/2001) - Initial Public Version